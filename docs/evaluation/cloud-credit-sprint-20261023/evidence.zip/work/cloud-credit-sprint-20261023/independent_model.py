"""Independent Silver wire runner, reusing the frozen Gemini mapper/parser.

This class is deliberately NOT a GeminiProviderAdapter subclass, so Product
cannot accept it through compose_task_provider. Actual wire/model metadata are
the requested Silver model; no Flash model label is substituted.
"""
from campaign_support import save
from linkloom.agents.providers import GeminiProviderAdapter
from linkloom.agents.providers.gemini_api import build_gemini_request,_exception_code,_make_error
from linkloom.agents.model_adapter import ModelResponse
from types import SimpleNamespace
import time


class IndependentSDKAdapter:
    def __init__(self,campaign,model_id):
        self.campaign=campaign;self.model_id=model_id
        self.parser=GeminiProviderAdapter(campaign.bridge)
        self.capability=self.parser.capability

    def invoke(self,request):
        try:
            payload=build_gemini_request(request,configured_model_id=self.model_id)
        except Exception as error:
            if error.__class__.__name__=='_AdapterFailure':
                return self.parser._failure_response(error)
            raise
        start=time.monotonic()
        try:
            raw=self.campaign.wire(**payload)
        except Exception as error:
            code,outcome=_exception_code(error)
            return ModelResponse(error=_make_error(code,outcome=outcome,
                details=dict(reason='independent_sdk_exception',exception_type=type(error).__name__)))
        try:
            return self.parser._parse_response(raw,request,self.model_id,
                (time.monotonic()-start)*1000,payload=payload)
        except Exception as error:
            if error.__class__.__name__=='_AdapterFailure':
                return self.parser._failure_response(error)
            raise

    def complete(self,request):
        index=self.campaign.session.requests+1
        request_path=self.campaign.root/f'normalized/{index:03}-request.json'
        if not request_path.exists():save(request_path,request.to_dict())
        response=self.campaign.session.complete(SimpleNamespace(complete=self.invoke),request.agent_id,request)
        response_path=self.campaign.root/f'normalized/{index:03}-response.json'
        if not response_path.exists():save(response_path,response.to_dict())
        print(dict(stage=request.agent_id,actual_wire_model=self.model_id,request=index,
            reserved_usd=self.campaign.session.cost,failure=self.campaign.session.failure),flush=True)
        return response
