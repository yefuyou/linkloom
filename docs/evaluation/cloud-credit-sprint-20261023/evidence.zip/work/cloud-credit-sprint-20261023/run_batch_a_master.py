"""M3-S live campaign + M3-Q Product HTTP helpers, no new Agent harness.

Default is offline plan only. --execute creates a fresh, non-overwriting run.
The immutable master-code.zip is the reproduction source; never use dirty src.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import json
import os
import sys
import time
from datetime import datetime, UTC
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
CODE = ROOT / 'code'
sys.path[:0] = [str(CODE / 'src'), str(CODE)]
sys.stdout.reconfigure(encoding='utf8')
SHA = '46b819fa39ace26de2c5470f7438b56df523c560'


def client(base, path, *, method='GET', data=None):
    # Same M3-Q helper, with an HTTP timeout that permits the live F/G stages.
    request = Request(base+path, method=method,
        data=None if data is None else json.dumps(data).encode('utf8'),
        headers={'Content-Type':'application/json'} if data is not None else {})
    try:
        response = urlopen(request, timeout=180)
    except HTTPError as error:
        response = error
    with response:
        return response.status, json.loads(response.read().decode('utf8'))


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf8') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())


def scenes():
    # Exact existing public M3-S scenes, no tuned replacement after results.
    import ast
    path = CODE / 'docs/requirements/m3-s-task-field-grounding/evidence/run_m3s_phase2.py'
    tree = ast.parse(path.read_text(encoding='utf8'))
    node = next(n.value for n in tree.body if isinstance(n, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == 'SCENES' for t in n.targets))
    return eval(compile(ast.Expression(node), str(path), 'eval'), {'__builtins__': {}, 'dict': dict})


def execute(out):
    from linkloom.agents.providers import GeminiProviderAdapter, build_gemini_sdk_client, GEMINI_38_FLASH_MODEL_ID
    from linkloom.ui.task_provider import TaskProviderSession, TaskProviderLimits, compose_task_provider
    from linkloom.ui.product import ProductApplication
    from tests.m3p_support import product_http

    assert os.environ.get('GEMINI_API_KEY'), 'GEMINI_API_KEY_UNSET'
    assert os.environ.get('GOOGLE_GENAI_USE_VERTEXAI', '').lower() not in {'1', 'true'}
    expiry = datetime(2026, 10, 23, 16, tzinfo=UTC)  # conservative China-date stop

    def valid():
        if datetime.now(UTC) >= expiry:
            raise RuntimeError('CREDIT_DATE_STOP')
        if (out / 'STOP').exists():
            raise RuntimeError('OPERATOR_STOP')

    valid()
    out.mkdir(parents=True, exist_ok=False)
    inputs = scenes()
    save(out / 'inputs-before-results.json', inputs)
    save(out / 'authorization.json', dict(code_sha=SHA, classification='DEV_DIAGNOSTIC',
        model=GEMINI_38_FLASH_MODEL_ID, sdk=importlib.metadata.version('google-genai'),
        python=sys.version, started_at=datetime.now(UTC).isoformat(),
        user_confirmed_credit_usable=True, credit_console_before_usd=139.34,
        credit_expiry_date='2026-10-24', actual_bill_usd=None,
        published_input_rate=.75, published_output_including_thinking_rate=3.75,
        pricing_url='https://ai.google.dev/gemini-api/docs/pricing',
        batch_max_cost_usd=3, total_plan_max_usd=95, safety_margin_usd=10,
        max_generation_requests=20, max_input_reserved=1200000,
        max_output_reserved=160000, max_seconds=900, sdk_attempts=1,
        original_runner='M3-S run_m3s_phase2.py + M3-Q product_http/_client',
        original_code_unchanged=True,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        source_archive_sha256=hashlib.sha256((ROOT/'master-code.zip').read_bytes()).hexdigest()))
    limits = TaskProviderLimits(20, 1200000, 160000, 3, 900, 65, .15)
    campaign = TaskProviderSession(out / 'campaign', limits, valid)
    sdk = build_gemini_sdk_client(os.environ['GEMINI_API_KEY'],
        http_options_kwargs=dict(timeout=60000, retry_options=dict(attempts=1)))
    wire_count = 0

    class Bridge:
        def generate_content(self, *, model, contents, config):
            nonlocal wire_count
            wire_count += 1
            prefix = out / 'wire' / f'{wire_count:03}'
            save(prefix.with_name(prefix.name+'-request.json'), dict(model=model, contents=contents, config=config,
                sent_at=datetime.now(UTC).isoformat()))
            start = time.monotonic()
            try:
                response = sdk.models.generate_content(model=model, contents=contents, config=config)
                raw = response.model_dump(mode='json')
                save(prefix.with_name(prefix.name+'-response.json'), dict(response=raw,
                    latency_ms=(time.monotonic()-start)*1000, received_at=datetime.now(UTC).isoformat()))
                return response
            except Exception as exc:
                # SDK exceptions can contain secrets/URLs: retain type only here.
                save(prefix.with_name(prefix.name+'-error.json'), dict(exception_type=type(exc).__name__,
                    latency_ms=(time.monotonic()-start)*1000, outcome='UNCERTAIN_OR_FAILED'))
                raise

    real = GeminiProviderAdapter(Bridge(), model_id=GEMINI_38_FLASH_MODEL_ID)

    class CampaignProvider(GeminiProviderAdapter):
        def complete(self, request):
            ordinal = campaign.requests + 1
            prefix = out / 'normalized' / f'{ordinal:03}'
            # Budget rejections may share ordinal; they do not replace receipts.
            if prefix.with_name(prefix.name+'-request.json').exists():
                return campaign.complete(real, request.agent_id, request)
            save(prefix.with_name(prefix.name+'-request.json'), request.to_dict())
            start = time.monotonic()
            response = campaign.complete(real, request.agent_id, request)
            save(prefix.with_name(prefix.name+'-response.json'), dict(response=response.to_dict(),
                stage=request.agent_id, latency_ms=(time.monotonic()-start)*1000))
            print(json.dumps(dict(event='request', sequence=ordinal, stage=request.agent_id,
                reserved=campaign.cost, failure=campaign.failure), ensure_ascii=False), flush=True)
            return response

    provider = CampaignProvider(Bridge(), model_id=GEMINI_38_FLASH_MODEL_ID)
    results = []
    try:
        for scene in inputs:
            if campaign.failure:
                results.append(dict(case=scene['id'], status='NOT_RUN', reason=campaign.failure))
                continue
            case_root = out / scene['id']
            case_root.mkdir()
            app = ProductApplication(database_path=case_root/'product.sqlite', extractor=None)
            service = compose_task_provider(app, provider,
                TaskProviderLimits(14, 600000, 100000, 3, 420, 65, .15))
            before = campaign.requests
            start = time.monotonic()
            try:
                with product_http(app, service) as base:
                    status, body = client(base, '/api/workspaces', method='POST', data={'name':'Credit sprint '+scene['id']})
                    assert status == 201, body
                    ws = body['workspace']['workspace_id']
                    client(base, '/api/workspaces/current', method='POST', data={'workspace_id':ws})
                    status, body = client(base, '/api/sources/import', method='POST',
                        data=dict(name='meetings.txt', content=scene['source']))
                    save(case_root/'source-import.json', body)
                    assert status == 202 and campaign.requests == before
                    _, config = client(base, '/api/product/ask/config')
                    save(case_root/'config-before-ask.json', config)
                    status, submitted = client(base, '/api/product/ask', method='POST',
                        data=dict(workspace_id=ws, query=scene['question'], allow_external_provider=True,
                            investigation_context=dict(domain='tasks', snapshot_hash=config['investigation_context']['snapshot_hash'])))
                    save(case_root/'submission.json', dict(http_status=status, body=submitted))
                    result = submitted.get('result', {})
                    end = time.monotonic()+430
                    while result.get('status') == 'INVESTIGATING' and time.monotonic() < end:
                        time.sleep(.4)
                        run_id = result.get('agent_run_id') or result.get('run_id')
                        status, polled = client(base, f'/api/product/ask/runs/{run_id}?workspace_id={ws}')
                        result = polled.get('result', {})
                    save(case_root/'result.json', result)
                    row = dict(case=scene['id'], classification='DEV_DIAGNOSTIC', status=result.get('status'),
                        http_status=status, workspace_id=ws, agent_run_id=result.get('agent_run_id'),
                        requests=campaign.requests-before, latency_seconds=time.monotonic()-start,
                        reviewer=result.get('reviewer'), campaign_failure=campaign.failure,
                        gold='M3-S historical diagnostic expectations; no independent heldout score')
                    save(case_root/'summary.json', row)
                    results.append(row)
                    print(json.dumps(row, ensure_ascii=False), flush=True)
            except Exception as exc:
                row = dict(case=scene['id'], status='FAILED', failure_stage='LOCAL_ORCHESTRATION',
                    exception_type=type(exc).__name__, requests=campaign.requests-before)
                save(case_root/'local-error.json', row)
                results.append(row)
                break
            finally:
                app.close()
    finally:
        sdk.close()
        save(out/'summary.json', dict(code_sha=SHA, cases=results, requests_reserved=campaign.requests,
            wire_requests=wire_count, cost_reserved_usd=campaign.cost, campaign_failure=campaign.failure,
            actual_bill_usd=None, promotional_deduction_usd=None, further_batches='GATED_ON_BILLING_AND_REVIEW'))
        files = {str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in out.rglob('*') if p.is_file()}
        save(out/'manifest.json', dict(code_sha=SHA, files=files))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--output', type=Path, default=ROOT/'batch-a')
    args = parser.parse_args()
    if args.execute:
        execute(args.output.resolve())
    else:
        print(json.dumps(dict(code_sha=SHA, scenes=scenes(), mode='OFFLINE_PLAN_ONLY',
            provider_requests=0, max_cost_usd=3), ensure_ascii=False, indent=2))
