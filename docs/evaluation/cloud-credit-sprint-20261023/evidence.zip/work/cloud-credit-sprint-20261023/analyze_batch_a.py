"""Recompute the report from durable receipts; no Provider/network imports."""
from pathlib import Path
from collections import Counter
import argparse
import csv
import hashlib
import json

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding='utf8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main(output):
    output.mkdir(parents=True, exist_ok=False)
    wires = []
    cases = []
    reservations = 0
    for campaign_name, names in [('batch-a', ['clear', 'ambiguous']), ('a3', ['ambiguous'])]:
        campaign = ROOT/campaign_name
        auth = read(campaign/'authorization.json')
        budget = read(campaign/'campaign/budget.json')
        reservations += budget['cost_reserved_usd']
        attempts = budget['attempts']
        assert budget['failure'] is None and all(a['outcome']=='SUCCEEDED' for a in attempts)
        for i, row in enumerate(attempts, 1):
            request = read(campaign/f'wire/{i:03}-request.json')
            raw = read(campaign/f'wire/{i:03}-response.json')
            response = raw['response']
            usage = response['usage_metadata']
            prompt = usage['prompt_token_count']
            candidate = usage['candidates_token_count']
            thoughts = usage.get('thoughts_token_count')
            total = usage['total_token_count']
            # Null thought counter is retained; total reconciliation is separate.
            billable_output_upper = max(candidate+(thoughts or 0), total-prompt)
            estimate = (prompt*.75+billable_output_upper*3.75)/1000000
            assert request['model']=='gemini-3.8-flash'
            assert response['response_id']==row['provider_response_id']
            assert prompt==row['usage']['input_tokens'] and total==row['usage']['total_tokens']
            assert total <= row['input_reserved']+row['output_reserved']
            wires.append(dict(campaign=campaign_name, sequence=i, stage=row['stage'],
                model=request['model'], actual_model_version=response.get('model_version'),
                sdk=auth['sdk'], code_sha=auth['code_sha'], response_id=response['response_id'],
                prompt_tokens=prompt, candidate_tokens=candidate, thoughts_tokens=thoughts,
                total_tokens=total, billable_output_upper_tokens=billable_output_upper,
                latency_ms=raw['latency_ms'], token_price_estimate_usd=estimate,
                cost_reserved_usd=row['cost_reserved_usd'], actual_bill_usd=None,
                thinking_config=request['config'].get('thinking_config'),
                configured_max_output_tokens=request['config'].get('max_output_tokens')))
        inputs = {s['id']:s for s in read(campaign/'inputs-before-results.json')}
        cursor = 0
        campaign_wires = [w for w in wires if w['campaign']==campaign_name]
        for name in names:
            result = read(campaign/name/'result.json')
            summary = read(campaign/name/'summary.json')
            case_wires = campaign_wires[cursor:cursor+summary['requests']]
            cursor += summary['requests']
            prep = result['preparation']
            discovery = prep['discovery']
            observations = discovery.get('valid_observations',[])+discovery.get('partial_observations',[])
            text = inputs[name]['source']
            checked = []
            for observation in observations:
                provenance = observation['provenance']
                assert provenance['content_hash']==sha(text.encode('utf8'))
                assert text[provenance['char_start']:provenance['char_end']]==provenance['quote']
                assert sha(provenance['quote'].encode('utf8'))==provenance['quote_sha256']
                for field in observation['field_evidence']:
                    assert text[field['char_start']:field['char_end']]==field['quote']
                if name=='ambiguous':
                    assert observation['owner'] is None and observation['deadline'] is None
                checked.append(dict(observation_id=observation['observation_id'],
                    ordinal=provenance['ordinal'], description=observation['description'],
                    owner=observation['owner'], deadline=observation['deadline'],
                    deadline_role=observation['deadline_role'], unknown_fields=observation['unknown_fields'],
                    exact_source_and_field_slices=True))
            by_id = {o['observation_id']:o for o in observations}
            semantic = next((t['result']['value'] for t in result['trace'] if t['tool']=='analyze_task_semantics'),None)
            proposals = []
            if semantic:
                assert semantic['execution']['new_live_provider_requests']==1 and not semantic['cache_hit']
                for p in semantic['proposals']:
                    left = by_id[p['subject']['observation_id']]['provenance']['ordinal']
                    right = by_id[p['object']['observation_id']]['provenance']['ordinal']
                    proposals.append(dict(predicate=p['predicate'], verdict=p['proposed_verdict'],
                        subject_ordinal=left, object_ordinal=right,
                        new_to_old_direction=(left>right) if p['predicate']=='REVISES_PLAN' else None,
                        supporting_quotes=[q['quote'] for q in p['supporting_evidence']],
                        counter_quotes=[q['quote'] for q in p['counter_evidence']],
                        evidence_status=p['evidence_status'], coverage=p['coverage']['status'],
                        publishable=p['publishable'], semantic_status=p['semantic_status'],
                        comparison=p.get('comparison')))
            cases.append(dict(case=f'{campaign_name}/{name}',code_sha=auth['code_sha'],
                classification='DEV_DIAGNOSTIC', status=result['status'],
                failure_stage='G_REPLAN_INPUT_BUDGET' if result['status']=='BLOCKED' else None,
                error=result['error'], requests=summary['requests'],
                latency_seconds=summary['latency_seconds'], source_sha256=sha(text.encode('utf8')),
                prompt_tokens=sum(w['prompt_tokens'] for w in case_wires),
                total_tokens=sum(w['total_tokens'] for w in case_wires),
                cost_reserved_usd=sum(w['cost_reserved_usd'] for w in case_wires),
                token_price_estimate_usd=sum(w['token_price_estimate_usd'] for w in case_wires),
                observation_count=len(observations), observations=checked,
                planning=[dict(status=p.get('status'),errors=p.get('errors'),provider_calls=p.get('provider_calls'),
                    proposed_steps=p.get('diagnostics',{}).get('proposed_steps')) for p in prep['planning']],
                executed_tools=[t['tool'] for t in result['trace']],proposals=proposals,
                reviewer=result['reviewer'], gaps=prep['gaps'],
                step_outcomes=dict(Counter(s['status'] for s in (result.get('task_review') or {}).get('steps',[])))))
    assert len(wires)<=20 and reservations<=3
    assert cases[1]['source_sha256']==cases[2]['source_sha256']
    aggregate = dict(classification='DEV_DIAGNOSTIC', cases=cases,
        requests=len(wires), provider_succeeded=len(wires), provider_failed=0, uncertain=0,
        stages=dict(Counter(w['stage'] for w in wires)),
        prompt_tokens=sum(w['prompt_tokens'] for w in wires),
        candidate_tokens=sum(w['candidate_tokens'] for w in wires),
        reported_thoughts_tokens=sum(w['thoughts_tokens'] or 0 for w in wires),
        null_thought_counter_requests=sum(w['thoughts_tokens'] is None for w in wires),
        total_tokens=sum(w['total_tokens'] for w in wires),
        provider_latency_ms=sum(w['latency_ms'] for w in wires),
        token_price_estimate_usd=sum(w['token_price_estimate_usd'] for w in wires),
        cost_reserved_usd=reservations, actual_bill_usd=None, promotional_deduction_usd=None,
        independent_gold_metrics='NOT_APPLICABLE', no_new_gemini_25=True,
        actual_charges_note='Published standard token-rate calculation, not a confirmed bill. Null thought counters retained.')
    (output/'aggregate.json').write_text(json.dumps(aggregate,ensure_ascii=False,indent=2),encoding='utf8')
    (output/'requests.json').write_text(json.dumps(wires,ensure_ascii=False,indent=2),encoding='utf8')
    with (output/'cases.csv').open('w',encoding='utf-8-sig',newline='') as f:
        columns=['case','code_sha','classification','status','failure_stage','requests','latency_seconds','observation_count','prompt_tokens','total_tokens','cost_reserved_usd','token_price_estimate_usd']
        writer=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');writer.writeheader();writer.writerows(cases)
    print(json.dumps({k:v for k,v in aggregate.items() if k!='cases'},ensure_ascii=False,indent=2))
    for c in cases:
        print(c['case'], c['status'], c['observation_count'],[(p['predicate'],p['verdict'],p['new_to_old_direction']) for p in c['proposals']])


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'analysis')
    main(parser.parse_args().output.resolve())
