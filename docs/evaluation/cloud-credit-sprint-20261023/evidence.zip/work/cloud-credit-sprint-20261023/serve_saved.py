"""Provider-free cold UI verification of existing LIVE artifacts.

The fixture bootstrap seeds only the same sessionStorage pointer used by the
existing verify_m3s_cold.py. Product, HTTP handlers, Renderer and revalidation
are unchanged. No generation, source update or business approval is exposed.
"""
from pathlib import Path
import argparse
import json
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--code', type=Path, required=True)
parser.add_argument('--case-root', type=Path, required=True)
parser.add_argument('--port', type=int, default=8769)
args = parser.parse_args()
sys.path[:0] = [str(args.code.resolve()/'src'), str(args.code.resolve())]
from linkloom.ui.product import ProductApplication
from linkloom.ui.investigation import ProductInvestigationService
from linkloom.ui.server import create_http_server
from tests.integration.test_product_application_flow import _UnusedRunBackend

root = args.case_root.resolve()
result = json.loads((root/'result.json').read_text(encoding='utf8'))
ws, run = result['workspace_id'], result['agent_run_id']
app = ProductApplication(database_path=root/'product.sqlite', extractor=None)
server = create_http_server(_UnusedRunBackend(), product_app=app,
    investigation_service=ProductInvestigationService(app), port=args.port)
original = server.RequestHandlerClass
key, value = json.dumps('linkloom:last-task:'+ws), json.dumps(run)


class ColdFixture(original):
    def do_GET(self):
        if self.path == '/evaluation-reopen':
            body = (f'<!doctype html><meta charset="utf-8"><title>Saved LIVE fixture</title>'
                f'<script>sessionStorage.setItem({key},{value});location.replace("/");</script>').encode('utf8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            super().do_GET()


server.RequestHandlerClass = ColdFixture
print(f'Provider-free cold UI: http://127.0.0.1:{server.server_port}/evaluation-reopen', flush=True)
try:
    server.serve_forever()
finally:
    server.server_close()
    app.close()
