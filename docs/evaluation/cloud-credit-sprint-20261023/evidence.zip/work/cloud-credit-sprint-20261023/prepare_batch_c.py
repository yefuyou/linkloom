"""Project existing public fixtures into the existing SemanticContext contract."""
from campaign_support import ROOT,WORK,CODE,read,save,digest
import shutil

out=ROOT/'c-inputs';out.mkdir(exist_ok=False)
raw_path=WORK/'linkloom-m2-integration-acceptance/tests/fixtures/m2_final/inputs/holdout.json'
shutil.copyfile(raw_path,out/'m2-original-input.json')
originals=read(raw_path)['cases'];cases=[]
for h in originals:
    groups=[('H04-v1',[0,1],h['questions'][:1]),('H04-v2',[0,2],h['questions'][1:])] if h['case_id']=='H04' else [(h['case_id'],list(range(len(h['sources']))),h['questions'])]
    for name,indices,questions in groups:
        source_handles={i:'source_'+str(i) for i in indices}
        sources=[dict(id=source_handles[i],artifact_id=h['sources'][i]['artifact_id'],
            source_type=h['sources'][i]['source_type'],content=h['sources'][i]['content']) for i in indices]
        selected=[o for o in h['observations'] if o['source_index'] in indices]
        handles={o['label']:'task_'+str(i) for i,o in enumerate(selected)}
        tasks=[dict(handle=handles[o['label']],source=source_handles[o['source_index']],ordinal=o['segment_index'],
            project=o['task']['project'],deadline_text=o['task']['deadline_text']) for o in selected]
        changes=[]
        if h.get('change'):
            change=h['change'];changes=[dict(handle='change',source=source_handles[change['source_index']],
                ordinal=change['segment_index'],project=change['project'],before=change['before'],after=change['after'])]
        queries=[]
        for q in questions:
            subject=handles[q['subject']];obj=handles[q['object']] if 'object' in q else 'change'
            if q['predicate']=='REVISES_PLAN': queries.append(['SAME_TASK',subject,obj])
            queries.append([q['predicate'],subject,obj])
        cases.append(dict(case_id=name,workspace_id='credit-c-'+name,question='逐项判断所请求关系，引用完整原文与正反证，保留未知；修订方向必须是后计划指向原计划。引用正确不等于正式批准。',
            sources=sources,tasks=tasks,projects=[],changes=changes,queries=queries,
            qualification='DEV_DIAGNOSTIC',original_case_id=h['case_id'],
            lifecycle_limit='H04 split snapshots do not prove historical retraction/replay or restore the original business score' if h['case_id']=='H04' else None))

new_path=WORK/'m3d-answer-first-integration/docs/requirements/m3-r-llm-first-semantic-closure/evidence/new-cases.json'
shutil.copyfile(new_path,out/'m3r-original-cases.json')
chosen={'shared-owner-distinct-work','progress-without-replanning','withdrawn-suggestion','opposed-minutes','missing-reference'}
for old in read(new_path)['cases']:
    if old['case_id'] not in chosen: continue
    sources=[dict(id=name,artifact_id=name,source_type='timestamped_text',
        content=f'[2030-01-0{i+1}T09:00:00+08:00] 唐予: '+old[field]+'\n')
        for i,(name,field) in enumerate([('before.txt','before'),('after.txt','after'),('counter.txt','extra')]) if field in old]
    cases.append(dict(case_id=old['case_id'],workspace_id='credit-c-'+old['case_id'],
        question='根据全部授权原文判断所请求关系，保留正反证和不确定性，不赋予业务批准。',
        sources=sources,tasks=[dict(handle='old',source='before.txt',ordinal=0,project=None,deadline_text=None),dict(handle='new',source='after.txt',ordinal=0,project=None,deadline_text=None)],
        projects=[],changes=[],queries=old['queries'],qualification='DEV_DIAGNOSTIC',existing_expected=old['expected']))
save(out/'cases.json',cases)
save(out/'manifest.json',dict(files={p.name:digest(p) for p in out.iterdir() if p.is_file()},
    qualification='DEV_DIAGNOSTIC; all cases seen during development, historical M2 0/4 untouched',
    model_inputs='Exact source text and author fixture endpoints only; no evaluator Gold or prior model answers',
    new_cases=len(cases),real_AMI_addition='At most one pair from B, only after immutable B observations exist; relation truth unlabelled'))
print('Frozen C:',len(cases),'semantic contexts; no Provider requests')
