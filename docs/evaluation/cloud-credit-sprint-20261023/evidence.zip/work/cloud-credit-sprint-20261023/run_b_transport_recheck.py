"""Exactly one bounded transport-recovery reattempt, never a retry loop.

Original failure remains N/E in first-pass results. The user's constraint bans
unlimited retry/over-budget reruns; this preserves the original 24/$6 batch cap.
"""
from campaign_support import ROOT,Campaign,phase_root,read,save,digest
from linkloom.semantic_ingestion.artifacts import RawArtifact
from linkloom.semantic_ingestion.document_text import parse_source_text
from linkloom.semantic_ingestion.extraction import ProviderNeutralSemanticExtractor,TaskDiscoveryProfile
from linkloom.semantic_ingestion.task_observation_discovery import TaskObservationDiscoveryService
from linkloom.decision_memory.sources import SourceReferenceRegistry
from linkloom.agents.providers import GEMINI_38_FLASH_MODEL_ID
import sys,time
sys.stdout.reconfigure(encoding='utf8')
first=read(phase_root('B')/'provider/budget.json')
assert first['requests_reserved']==1 and first['attempts'][0]['outcome']=='FAILED'
assert first['attempts'][0]['error']['details']['low_level_failure_class']=='TRANSPORT_TLS'
assert read(ROOT/'transport-metadata-preflight.json')['status']=='AVAILABLE'
assert read(phase_root('B').with_name(phase_root('B').name+'-unattempted')/'closed.json')['failure'] is None
job=read(ROOT/'b-inputs/jobs.json')[0]
campaign=Campaign('B',segment='tls-recheck')
save(campaign.root/'recheck-boundary.json',dict(max_attempts=1,reason='Known TLS failure, then successful metadata and 19 successful independent requests',
    original_ledger_sha256=digest(phase_root('B')/'provider/budget.json'),
    source_sha256=__import__('hashlib').sha256(job['source'].encode()).hexdigest(),
    evaluation='RECOVERY_ATTEMPT_NOT_FIRST_PASS; preserve original N/E',sdk_attempts=1))
try:
    artifact=RawArtifact('credit-b-public',job['id'],job['source_type'],job['source'])
    registry=SourceReferenceRegistry()
    for segment in parse_source_text(artifact).segments:
        registry.register_evidence(artifact.workspace_id,segment.evidence_span.evidence_ref,content_hash=artifact.content_hash,source_version=artifact.artifact_version_id)
    extractor=ProviderNeutralSemanticExtractor(campaign.provider,provider_id='gemini',model_id=GEMINI_38_FLASH_MODEL_ID,
        request_guard=campaign.guard,request_guard_id='credit-B',max_attempts=1,max_output_tokens=8192)
    result=TaskObservationDiscoveryService(extractor,source_registry=registry,current_source=lambda ws,aid:artifact,
        task_profile=TaskDiscoveryProfile.TASK_RECALL_V3).discover((artifact,),workspace_id=artifact.workspace_id)
    observations=(*result.valid_observations,*result.partial_observations)
    assert all(o.verify(artifact) for o in observations)
    row=dict(id=job['id'],status='EXTRACTION_FAILED' if any(x.failure_code for x in result.extractions) else 'EXECUTED',
        source_snapshot=job,discovery=result.to_dict(),observation_count=len(observations),evaluation='RECOVERY_ATTEMPT_NOT_FIRST_PASS')
    save(campaign.root/'synthetic-1.json',row);print({k:row[k] for k in ['id','status','observation_count','evaluation']},flush=True)
finally: campaign.close()
