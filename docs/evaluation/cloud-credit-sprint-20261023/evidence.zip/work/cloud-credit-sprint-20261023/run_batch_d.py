"""Independent MACHINE_SILVER through the existing SDK mapper and F/C runners."""
from campaign_support import ROOT,Campaign,read,save,digest
from independent_model import IndependentSDKAdapter
from linkloom.agents.model_adapter import ModelTurnRequest,ModelGenerationOptions
from linkloom.tools.contracts import ToolDefinition
from linkloom.semantic_ingestion.artifacts import RawArtifact
from linkloom.semantic_ingestion.document_text import parse_source_text
from linkloom.semantic_ingestion.extraction import ProviderNeutralSemanticExtractor,TaskDiscoveryProfile
from linkloom.semantic_ingestion.task_observation_discovery import TaskObservationDiscoveryService
from linkloom.decision_memory.sources import SourceReferenceRegistry
from linkloom.semantic_ingestion.task_relation_semantic_proposer import SemanticProposer
from linkloom.semantic_ingestion.task_relation_semantic_validation import validate_proposals
from tests.task_semantic_support import context_for
import sys

sys.stdout.reconfigure(encoding='utf8')
MODEL='gemini-4-argon'
jobs=[j for j in read(ROOT/'b-inputs/jobs.json') if j['id'] in {'ES2002a-6','ES2002b-2'}]
cases=[c for c in read(ROOT/'c-inputs/cases.json') if c['case_id'] in {'H03','shared-owner-distinct-work'}]
resume='--resume' in sys.argv
campaign=Campaign('D',input_rate=2,output_rate=10,segment='parameter-repair' if resume else None);rows=[]
save(campaign.root/'selection.json',dict(qualification='MACHINE_SILVER',jobs=jobs,relation_cases=cases,
    rule='Same immutable public inputs; no Flash outputs or evaluator labels in model input',
    estimate_usd=.6,max_requests=8,adapter_sha256=digest(ROOT/'independent_model.py'),
    prices=dict(input_per_million=2,output_per_million=10,source='https://ai.google.dev/gemini-api/docs/pricing',billing_actual=None)))
try:
    if resume:
        from campaign_support import phase_root
        assert read(phase_root('D')/'protocol.json')['status']=='PASS'
        save(campaign.root/'availability.json',dict(status='REUSED_SUCCESSFUL_PROTOCOL',
            prior_protocol_sha256=digest(phase_root('D')/'protocol.json'),no_duplicate_probe=True))
    else:
        metadata=campaign.sdk.models.get(model=MODEL)
        save(campaign.root/'availability.json',dict(status='AVAILABLE_METADATA',model=metadata.model_dump(mode='json')))
    adapter=IndependentSDKAdapter(campaign,MODEL)
    tool=ToolDefinition('emit_probe','1','Return protocol status',dict(type='object',properties=dict(status=dict(type='string',enum=['ok'])),required=['status'],additionalProperties=False),dict(type='object'))
    probe=ModelTurnRequest('silver-probe','t1','task','silver',1,'Public protocol probe. Call emit_probe with status ok.',None,[tool],
        model_id=MODEL,generation_options=ModelGenerationOptions(max_output_tokens=512,require_tool_call=True,thinking_level='low'))
    if not resume:
        response=adapter.complete(probe)
        valid=response.error is None and response.action is not None and response.action.tool_call is not None and response.action.tool_call.arguments==dict(status='ok')
        save(campaign.root/'protocol.json',dict(status='PASS' if valid else 'FAIL',response=response.to_dict()))
        if not valid:raise RuntimeError('STRONG_MODEL_PROTOCOL_UNAVAILABLE_STOP')
    for job in jobs:
        if campaign.session.failure:break
        artifact=RawArtifact('credit-b-public',job['id'],job['source_type'],job['source'])
        registry=SourceReferenceRegistry()
        for segment in parse_source_text(artifact).segments:
            registry.register_evidence(artifact.workspace_id,segment.evidence_span.evidence_ref,content_hash=artifact.content_hash,source_version=artifact.artifact_version_id)
        extractor=ProviderNeutralSemanticExtractor(adapter,provider_id='gemini',model_id=MODEL,
            request_guard=campaign.guard,request_guard_id='credit-D',max_attempts=1,max_output_tokens=8192,
            temperature=None,thinking_level='low')
        result=TaskObservationDiscoveryService(extractor,source_registry=registry,current_source=lambda ws,aid:artifact,
            task_profile=TaskDiscoveryProfile.TASK_RECALL_V3).discover((artifact,),workspace_id=artifact.workspace_id)
        row=dict(id=job['id'],qualification='MACHINE_SILVER',source_snapshot=job,discovery=result.to_dict(),
            status='EXTRACTION_FAILED' if any(e.failure_code for e in result.extractions) else 'EXECUTED')
        save(campaign.root/f'cases/{job["id"]}.json',row);rows.append(dict(id=job['id'],status=row['status'],observations=len(result.valid_observations)+len(result.partial_observations)))
        print(rows[-1],flush=True)
    proposer=SemanticProposer(adapter,model_id=MODEL,request_guard=campaign.guard,guard_id='credit-D')
    for case in cases:
        if campaign.session.failure:break
        context=context_for(case);result=proposer.propose(context)
        row=dict(id=case['case_id'],qualification='MACHINE_SILVER',source_snapshot=case,
            status=result.status,errors=list(result.errors),proposals=[p.to_dict() for p in result.proposals],
            validation=[v.to_dict() for v in validate_proposals(result,context)],usage=result.usage.to_dict())
        save(campaign.root/f'cases/{case["case_id"]}.json',row);rows.append(dict(id=case['case_id'],status=result.status,verdicts=[p.proposed_verdict for p in result.proposals]))
        print(rows[-1],flush=True)
except Exception as exc:
    save(campaign.root/'stopped.json',dict(exception_type=type(exc).__name__,reason=str(exc) if isinstance(exc,RuntimeError) else 'METADATA_OR_LOCAL_BOUNDARY_FAILURE'))
    print(dict(stopped=type(exc).__name__),flush=True)
finally:
    save(campaign.root/'cases-summary.json',rows);campaign.close()
