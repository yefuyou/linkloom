"""Offline receipt/Gold analysis. Never imports Provider code or sends requests."""
from pathlib import Path
from collections import Counter
import argparse,csv,hashlib,json,shutil

ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,data):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf8') as f:json.dump(data,f,ensure_ascii=False,indent=2)
def lines(p):return [json.loads(s) for s in Path(p).read_text(encoding='utf8').splitlines() if s.strip()]
def observations(row):
    d=row['discovery'];return d['valid_observations']+d['partial_observations']
def claims(row):return [c for e in row['discovery']['extractions'] for c in e['claims']]
def field_view(o):return {k:o.get(k) for k in ['description','owner','deadline','project','unknown_fields']}

def main(out):
    out.mkdir(exist_ok=False);phases={};requests=[]
    A=read(ROOT/'analysis-final/aggregate.json')
    for phase in 'BCDE':
        roots=sorted(WORK.glob('ce-'+phase.lower()+'-20261023*'))
        ledgers=[read(r/'provider/budget.json') for r in roots if (r/'provider/budget.json').exists()]
        assert all((r/'closed.json').exists() for r in roots)
        wires=[]
        for root in roots:
            for p in sorted((root/'wire').glob('*-response.json')):
                raw=read(p);body=raw['response'];u=body['usage_metadata']
                wire=read(p.with_name(p.name.replace('response','request')))
                assert '2.5' not in wire['model']
                rate=(2,10) if wire['model']=='gemini-4-argon' else (.75,3.75)
                billout=max((u.get('candidates_token_count') or 0)+(u.get('thoughts_token_count') or 0),u['total_token_count']-u['prompt_token_count'])
                row=dict(phase=phase,segment=root.name,sequence=int(p.name[:3]),model=wire['model'],model_version=body['model_version'],
                    response_id=body['response_id'],prompt_tokens=u['prompt_token_count'],candidate_tokens=u.get('candidates_token_count'),
                    thoughts_tokens=u.get('thoughts_token_count'),total_tokens=u['total_token_count'],billable_output_upper_tokens=billout,
                    latency_ms=raw['latency_ms'],token_price_estimate_usd=(u['prompt_token_count']*rate[0]+billout*rate[1])/1e6,
                    actual_bill_usd=None,request_sha256=sha(p.with_name(p.name.replace('response','request'))),response_sha256=sha(p))
                wires.append(row);requests.append(row)
        attempts=[a for b in ledgers for a in b['attempts']]
        phases[phase]=dict(reservations=sum(b['requests_reserved'] for b in ledgers),
            actual_wire_requests=sum(read(r/'closed.json')['wire_requests'] for r in roots),responses=len(wires),
            original_outcomes=dict(Counter(a['outcome'] for a in attempts)),
            resolved_prewire_failures=sum((r/'prewire-resolution.json').exists() for r in roots),
            reserved_usd=sum(b['cost_reserved_usd'] for b in ledgers),actual_bill_usd=None,
            prompt_tokens=sum(r['prompt_tokens'] for r in wires),total_tokens=sum(r['total_tokens'] for r in wires),
            candidate_tokens=sum(r['candidate_tokens'] or 0 for r in wires),thoughts_tokens=sum(r['thoughts_tokens'] or 0 for r in wires),
            provider_latency_ms=sum(r['latency_ms'] for r in wires),token_price_estimate_usd=sum(r['token_price_estimate_usd'] for r in wires),
            roots=[str(r) for r in roots])
    b1=read(WORK/'ce-b-20261023-tls-recheck/synthetic-1.json')
    b2=read(WORK/'ce-b-20261023-unattempted/cases/synthetic-2.json')
    by_job={'synthetic-1':b1,'synthetic-2':b2};diagnostics=[]
    for case in read(ROOT/'b-inputs/diagnostic-expectations.json'):
        row=by_job[case['job']];obs=observations(row)
        for expected in case['expected']:
            matches=[o for o in obs if o['provenance']['ordinal']==case['ordinal'] and expected['anchor'] in o['description']]
            raw_matches=[c for c in claims(row) if c.get('task') and any(expected['anchor'] in s for s in c['task']['description_parts'])]
            fields=bool(len(matches)==1 and all(matches[0].get(k)==expected.get(k) for k in ['owner','deadline','project','vendor']))
            variant=bool(len(matches)==1 and matches[0].get('project')==str(expected.get('project'))+'项目'
                and all(matches[0].get(k)==expected.get(k) for k in ['owner','deadline','vendor']))
            diagnostics.append(dict(case_id=case['case_id'],qualification='DEV_DIAGNOSTIC',expected=expected,
                model_proposed=bool(raw_matches),admitted_count=len(matches),fields_match=fields,
                literal_project_label_variant=variant,
                admitted=[field_view(o) for o in matches],failure_stage=None if fields else 'EVALUATOR_LITERAL_LABEL_VARIANT' if variant else 'DISCOVERY' if raw_matches else 'MODEL_EXTRACTION',
                first_pass='N/E_TRANSPORT_FAILURE' if case['job']=='synthetic-1' else 'EXECUTED',
                all_discovery_failures=row['discovery']['failures']))
    save(out/'b-synthetic-diagnostics.json',diagnostics)
    ami=[read(p) for p in sorted((WORK/'ce-b-20261023-unattempted/cases').glob('ES*.json'))]
    save(out/'b-ami-diagnostics.json',[dict(id=r['id'],observations=[field_view(o) for o in observations(r)],
        model_claims=len(claims(r)),failures=r['discovery']['failures'],meeting_coverage=r['source_snapshot']['meeting_coverage']) for r in ami])
    product=read(WORK/'ce-b-20261023-unattempted/product/result.json')
    pobs=product['preparation']['discovery']['valid_observations']+product['preparation']['discovery']['partial_observations']
    save(out/'b-product.json',dict(status=product['status'],observations=[field_view(o) for o in pobs],
        all_unknown=all(o['owner'] is None and o['deadline'] is None for o in pobs),reviewer=product['reviewer'],
        tools=[t['tool'] for t in product['trace']],evidence_count=len(product['evidence'])))
    crows=[]
    for p in sorted((WORK/'ce-c-20261023-resume/cases').glob('*.json')):
        c=read(p);crows.append(dict(id=c['id'],status=c['status'],qualification=c['qualification'],verdicts=c['verdicts'],
            expected=c.get('existing_expected'),expected_match=c.get('existing_expected')==c['verdicts'] if c.get('existing_expected') else None,
            queries=c['source_snapshot']['queries'],validation=c['validation'],lifecycle_limit=c['lifecycle_limit']))
    save(out/'c-diagnostics.json',crows)
    comparisons=[]
    for p in sorted((WORK/'ce-d-20261023-parameter-repair/cases').glob('*.json')):
        d=read(p);cp=WORK/('ce-b-20261023-unattempted/cases' if p.stem.startswith('ES') else 'ce-c-20261023-resume/cases')/p.name
        flash=read(cp)
        if 'discovery' in d:
            left=[field_view(o) for o in observations(flash)];right=[field_view(o) for o in observations(d)]
            detail=dict(flash_claims=[c.get('task') for c in claims(flash)],silver_claims=[c.get('task') for c in claims(d)],
                flash_failures=flash['discovery']['failures'],silver_failures=d['discovery']['failures'])
        else:
            left=[p['proposed_verdict'] for p in flash['proposals']];right=[p['proposed_verdict'] for p in d['proposals']]
            detail=dict(flash_proposals=flash['proposals'],silver_proposals=d['proposals'],flash_validation=flash['validation'],silver_validation=d['validation'])
        comparisons.append(dict(id=p.stem,qualification='MACHINE_SILVER',flash=left,silver=right,equal=left==right,**detail))
    save(out/'d-model-comparisons.json',comparisons)
    e=read(WORK/'ce-e-20261023/cases-summary.json');e_pre=read(WORK/'ce-e-20261023/preflight.json')
    save(out/'e-comparison.json',dict(readers=e,compactor=read(WORK/'ce-e-20261023/llm-compaction.json'),
        native_history_bytes=e_pre['total_history_bytes'],scope=e_pre['scope'],whole_meeting_uncompressed=e_pre['whole_meeting_uncompressed']))
    # Official annotations are consulted only after all model inputs were frozen.
    goldroot=WORK/'ami-public-gold-benchmark/work/ami-public-v1/data-04/evaluator_only'
    manifest=read(goldroot/'manifest.json')
    assert all(sha(goldroot/k)==v for k,v in manifest['files'].items())
    for name in ['manifest.json','qrels.jsonl','provenance.jsonl']:
        dest=out/'gold-snapshot'/name;dest.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(goldroot/name,dest)
    provenance=lines(goldroot/'provenance.jsonl')
    action_ids={p['query_id'] for p in provenance if p['section']=='actions'}
    qrels=[q for q in lines(goldroot/'qrels.jsonl') if q['meeting_id'] in {'ES2002a','ES2002b'}]
    golden=[]
    for q in qrels:
        if q['query_id'] not in action_ids:continue
        relevant=set(q['relevant_dialogue_act_ids']);matched=[]
        for r in ami:
            if r['source_snapshot']['meeting_id']!=q['meeting_id']:continue
            for u in r['source_snapshot']['utterance_spans']:
                uid=u.get('utterance_id',u.get('id'))
                if uid not in relevant:continue
                # Coordinates include native header; description must map to
                # exact text in the linked utterance, not an entire chunk quote.
                a=u['local_start'];b=u['local_end'];text=r['source_snapshot']['source'][a:b]
                admitted=[o['description'] for o in observations(r) if o['description'] in text]
                proposed=[part for c in claims(r) if c.get('task') for part in c['task']['description_parts'] if part in text]
                matched.append(dict(job=r['id'],utterance_id=uid,admitted_descriptions=admitted,exact_model_description_parts=proposed))
        golden.append(dict(query_id=q['query_id'],query_text=q['query_text'],official_relevant_ids=sorted(relevant),
            evidence_in_model_input=bool(matched),native_span_matches=matched,
            qualification='OFFICIAL_HUMAN_LINKED_SPAN_DIAGNOSTIC',
            formal_task_extraction_metrics='N/E: original Gold task is retrieval; no exhaustive action identity/owner/deadline labels'))
    save(out/'official-gold-qualification.json',dict(upstream='AMI Manual Annotations 1.7 / official human abstractive summary links',
        original_task='QUERY_TO_OFFICIAL_LINKED_DIALOGUE_ACT_RETRIEVAL',formal_retrieval_metrics='NOT_RUN: no retrieval experiment in this batch',
        formal_task_extraction_metrics='N/E_INCOMPATIBLE_LABEL_TASK',no_model_gold_input=True,rows=golden,
        original_manifest_sha256=sha(goldroot/'manifest.json')))
    transcript=read(ROOT/'b-inputs/ES2002a.json')
    utterances={u['utterance_id']:u for u in transcript['utterances']}
    action_refs={i for q in golden if q['query_id'].startswith('ES2002a:') for i in q['official_relevant_ids']}
    e_coverage=[]
    for name,index in [('bounded_uncompressed',3),('deterministic',4),('llm_hint',5)]:
        model_input=read(WORK/f'ce-e-20261023/normalized/{index:03}-request.json')['user_input']
        e_coverage.append(dict(variant=name,qualification='OFFICIAL_LINKED_TEXT_AVAILABILITY_DIAGNOSTIC_NOT_SEMANTIC_GOLD',
            linked_source_text=[dict(utterance_id=i,original_text=utterances[i]['text'],present_as_exact_original=utterances[i]['text'] in model_input)
                for i in sorted(action_refs)],
            limitation='Additional source-linked action text was not declared necessary in the protected state. No assertion that a hint constitutes original evidence.'))
    save(out/'e-additional-context-loss.json',e_coverage)
    total=dict(reservations=A['requests']+sum(p['reservations'] for p in phases.values()),
        actual_wire_requests=A['requests']+sum(p['actual_wire_requests'] for p in phases.values()),
        responses=A['provider_succeeded']+sum(p['responses'] for p in phases.values()),
        reserved_usd=A['cost_reserved_usd']+sum(p['reserved_usd'] for p in phases.values()),
        prompt_tokens=A['prompt_tokens']+sum(p['prompt_tokens'] for p in phases.values()),
        total_tokens=A['total_tokens']+sum(p['total_tokens'] for p in phases.values()),
        provider_latency_ms=A['provider_latency_ms']+sum(p['provider_latency_ms'] for p in phases.values()),
        token_price_estimate_usd=A['token_price_estimate_usd']+sum(p['token_price_estimate_usd'] for p in phases.values()),
        actual_bill_usd=None,promotional_deduction_usd=None,unresolved_provider_outcomes=0,
        known_failures=['B first-pass TLS failure','D temperature error, offline proven NOT_SENT_PREWIRE; original UNCERTAIN ledger retained'])
    save(out/'aggregate.json',dict(A=A,B_to_E=phases,total=total,
        synthetic_model_candidates=sum(d['model_proposed'] for d in diagnostics),synthetic_admitted=sum(d['admitted_count']==1 for d in diagnostics),
        synthetic_total=len(diagnostics),synthetic_fields_pass=sum(d['fields_match'] for d in diagnostics),
        C_proposals=sum(len(c['verdicts']) for c in crows),C_quote_validation_failures=sum(bool(v['errors']) for c in crows for v in c['validation']),
        D_comparisons=len(comparisons),D_equal=sum(c['equal'] for c in comparisons)))
    save(out/'requests.json',requests)
    with (out/'batch-summary.csv').open('x',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['phase','reservations','actual_wire_requests','responses','reserved_usd','prompt_tokens','total_tokens','provider_latency_ms','token_price_estimate_usd','actual_bill_usd'])
        writer.writeheader()
        for phase,row in phases.items():writer.writerow(dict(phase=phase,**{k:row[k] for k in writer.fieldnames if k!='phase'}))
    save(out/'manifest.json',{str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()})
    print(json.dumps(dict(phases=phases,total=total,synthetic=(sum(d['fields_match'] for d in diagnostics),len(diagnostics)),
        C_quote_failures=sum(bool(v['errors']) for c in crows for v in c['validation']),official_action_rows=len(golden)),ensure_ascii=False,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();main(args.output)
