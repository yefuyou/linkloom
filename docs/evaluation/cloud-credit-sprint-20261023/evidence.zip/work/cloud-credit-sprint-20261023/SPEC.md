# Google Cloud credit evaluation sprint — 2026-10-23

Authorization: user's ordered A–E evaluation request and confirmation that the
existing credit/API route is usable. No new product milestone or Harness.

Code: remote master `46b819fa39ace26de2c5470f7438b56df523c560`, verified by
`git ls-remote origin refs/heads/master`; execute an immutable Git archive.
Preserve the original dirty checkout and every historical result.

Batch A reuses M3-S public synthetic clear/ambiguous meetings and normal
Product HTTP entry, M3-Q HTTP helpers, existing F/G/Runtime/SemanticAnalysis,
GeminiProviderAdapter and TaskProviderSession. Both cases are DEV_DIAGNOSTIC.
Freeze source text and expected diagnostic criteria before sending anything.
Expect task extraction, a bounded plan, actual semantic tool execution where
the plan permits, source-grounded non-authoritative proposals, Reviewer output,
original evidence, and explicit UNKNOWN rather than fabricated owner/date.
Preserve all BLOCKED/UNKNOWN/PARTIAL/FAILED/N/E and the stage of failure.

Limits: A <= USD 3, <=20 generation requests, <=1,200,000 conservative input
token reservations, <=160,000 output token reservations, <=900 seconds;
one SDK attempt per request, SDK timeout 60s, campaign timeout 65s per request,
serial cases; stop on known failure/UNCERTAIN/budget/expiry. Reserve before
send, never release uncertain reservations. Capture raw SDK payload/response,
usage including thinking, latency, IDs, normalized requests/responses and all
Product artifacts. Secrets must not appear in artifacts.

Official current standard Flash rates: USD .75/1M input, 3.75/1M output
including thinking, through 2026-12-31. Use conservative USD 1/5 reservation
rates and >= USD .15 per request. No web search/maps, files, embeddings or
other billable tools. Worst-case campaign reservation <= USD 3. Before-run
estimate for two cases: 14–20 requests, <=120k actual input and <=32k output,
about USD .21 at published rates; reservation, estimate and bill are distinct.

Billing Console refreshed before execution: hackathon credit USD 139.34 of
150, expires 2026-10-24. User subsequently confirmed credit use is available.
Total planned maximum <= min(95, 139.34-10)=95. A is the only active budget.
No purchases, auto-reload, card changes or remote changes.

B–E require A review, demonstrated promotional deduction and reproducibility,
and verified enforceable cost controls. No launches while billing remains
uncertain; no scheduled background paid work. Prepare qualified cohorts offline
while waiting. AMI official summary-to-DA links qualify retrieval metrics only,
not exhaustive action-extraction Gold. H01–H04 remain DEV_DIAGNOSTIC. Any
strong-model comparison is MACHINE_SILVER and must use an independently
validated interface. E may use existing experimental seams only, preserving
Runtime and production context limits.

Acceptance is evidence, not a PASS target: publish a fresh summary, code/SDK/
source hashes, per-case and per-stage status, cost qualifications, runnable
script and prioritized failures. No README score edits, commits, pushes or PRs.

Predeclared A03 code contrast after A01/A02: master reproduced the documented
G replan INPUT_BUDGET_EXCEEDED. Existing M3-D + Answer-first candidate
`d0c64361ce0613d021d5d950954f7b0da6d2fabe` contains S1/S2, is clean locally,
and is not an ancestor of master. Run only the identical ambiguous case there,
preserving the master failure. Subtract the completed master campaign's 9
requests / USD 1.35 reservations and token usage from the SAME A cap; no reset.
No automatic retry or code repair; archive both code versions. This is a
diagnostic version comparison, not independent validation. Preserve the exact
original runner as run_batch_a_master.py before adding case/snapshot selection.
