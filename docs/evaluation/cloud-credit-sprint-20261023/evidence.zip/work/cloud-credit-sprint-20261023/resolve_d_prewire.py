"""Offline reconciliation; immutable failed ledger and reserved $1 retained."""
from campaign_support import ROOT,phase_root,read,save,digest,unresolved
from linkloom.agents.model_adapter import ModelTurnRequest
from linkloom.agents.providers.gemini_api import build_gemini_request
p=phase_root('D');ledger=p/'provider/budget.json';request=p/'normalized/002-request.json'
b=read(ledger)
assert b['attempts'][1]['outcome']=='UNCERTAIN' and read(p/'closed.json')['wire_requests']==1
assert sorted(f.name for f in (p/'wire').glob('*'))==['001-request.json','001-response.json']
try:build_gemini_request(ModelTurnRequest.from_dict(read(request)),configured_model_id='gemini-4-argon')
except Exception as exc:
    assert exc.__class__.__name__=='_AdapterFailure' and exc.details=={'reason':'temperature_unsupported_for_gemini_3'}
else:raise AssertionError('EXPECTED_PREWIRE_FAILURE_NOT_REPRODUCED')
save(p/'prewire-resolution.json',dict(sequence=2,resolution='NOT_SENT_PREWIRE',ledger_sha256=digest(ledger),request_sha256=digest(request),
    known_error='MODEL_INVALID_REQUEST',details=exc.details if False else {'reason':'temperature_unsupported_for_gemini_3'},
    budget_reserved_retained_usd=1,wire_requests=1,missing_second_wire_proven_by_replay=True,
    charge_for_second_request_usd=0,actual_bill_for_first_probe=None,script_sha256=digest(__file__)))
assert unresolved(ledger,b) is False
print('Offline reconciliation PASS; original ledger unchanged, full reservation retained.')
