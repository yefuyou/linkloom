"""Bounded native AMI history replay, existing compaction/recovery contracts."""
from campaign_support import ROOT,Campaign,save,digest
from compaction_eval import *
from dataclasses import replace,asdict
from linkloom.context.working import compact_working_context
from linkloom.runtime.context_engineering import ContextRuntimeConfig,FakeHistoryCompactor
from linkloom.agents.providers.gemini_api import build_gemini_request
import sys,time
sys.stdout.reconfigure(encoding='utf8')
state,recovery,source=build_state();config=ContextRuntimeConfig();policy=config.policy
restored=recovery.restore(workspace_id=state.workspace_id,refs=state.evidence_refs)
# Complete bounded baselines before enabling any paid call.
build_gemini_request(reader_request(state,restored))
det=compact_working_context(state,compactor=FakeHistoryCompactor(),recovery=recovery,max_tokens=config.working_max_tokens,policy=policy)
assert det.status=='complete'
campaign=Campaign('E');rows=[]
save(campaign.root/'preflight.json',dict(qualification='DEV_DIAGNOSTIC_COMPONENT_REPLAY',native_source_sha256=source.resource.content_hash,
    baseline_state=json.loads(state.to_json()),deterministic=asdict(det),runtime_config=config.identity(),
    total_history_bytes=sum(len(o.encode()) for o in state.operations),
    scope='Native AMI bounded history replay; not automatic production Runtime compaction or independent semantic accuracy',
    whole_meeting_uncompressed='N/E: full 60579-character meeting exceeds existing SDK 32KiB per-input cap; cap unchanged',
    estimate_usd=.4,max_new_calls=5,scripts={p:digest(ROOT/p) for p in ['compaction_eval.py','run_batch_e.py']}))
try:
    compactor=LLMHintCompactor(campaign.provider)
    probe_state=replace(state,operations=('Public protocol probe: unresolved questions remain pending; no completion evidence.',))
    probe=compact_working_context(probe_state,compactor=compactor,recovery=recovery,max_tokens=4096,policy=policy)
    assert probe.status=='complete' and probe.state.unresolved_questions==state.unresolved_questions
    save(campaign.root/'compactor-protocol.json',dict(status='PASS',result=asdict(probe)))
    before=campaign.session.requests;start=time.monotonic()
    llm=compact_working_context(state,compactor=compactor,recovery=recovery,max_tokens=4096,policy=policy)
    save(campaign.root/'llm-compaction.json',dict(result=asdict(llm),elapsed_ms=(time.monotonic()-start)*1000,calls=campaign.session.requests-before))
    assert llm.status=='complete'
    for name,current,quotes in [('bounded_uncompressed',state,restored),('deterministic',det.state,det.recovery),('llm_hint',llm.state,llm.recovery)]:
        if campaign.session.failure:break
        req=reader_request(current,quotes);build_gemini_request(req)
        start=time.monotonic();response=campaign.provider.complete(req);answer=arguments(response,'emit_context_check')
        refs={e.ref.evidence_id:e.quote for e in quotes.evidence}
        valid={c['evidence_id'] for c in answer['citations'] if c.get('evidence_id') in refs and c.get('quote') and c['quote'] in refs[c['evidence_id']]}
        row=dict(id=name,status='EXECUTED',qualification='DEV_DIAGNOSTIC_COMPONENT_REPLAY',answer=answer,usage=response.usage.to_dict(),
            elapsed_ms=(time.monotonic()-start)*1000,request_bytes=len(encode(req.to_dict()).encode()),state_bytes=len(current.to_json().encode()),
            pending_retained=set(state.unresolved_questions).issubset(answer['pending_questions']),
            necessary_evidence_coverage=len(valid)/len(refs),protected_state_preserved=current.unresolved_questions==state.unresolved_questions,
            required_quote_hashes=[e.ref.quote_hash for e in quotes.evidence],business_completion=answer['business_completion'])
        save(campaign.root/f'cases/{name}.json',row);rows.append(row);print({k:row[k] for k in ['id','status','pending_retained','necessary_evidence_coverage','request_bytes']},flush=True)
except Exception as exc:
    save(campaign.root/'stopped.json',dict(exception_type=type(exc).__name__,reason=str(exc) if isinstance(exc,RuntimeError) else 'LOCAL_CONTRACT_FAILURE'))
    print(dict(stopped=type(exc).__name__),flush=True)
finally:
    save(campaign.root/'cases-summary.json',rows);campaign.close()
