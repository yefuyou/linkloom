"""Freeze diagnostic sources/expectations; AMI selection is Gold-independent."""
from pathlib import Path
import json,hashlib,shutil
from campaign_support import ROOT,WORK,read,save,digest

out=ROOT/'b-inputs';out.mkdir(exist_ok=False)
cases=[
 dict(id='B01',text='黎舟负责完成缓存迁移，并由孟岚验证恢复流程；两项均在2038-05-20前提交。',expected=[
     dict(anchor='缓存迁移',owner='黎舟',deadline='2038-05-20'),dict(anchor='恢复流程',owner='孟岚',deadline='2038-05-20')]),
 dict(id='B02',text='搜索索引重建确定照常做，负责人尚未敲定，完成日期也未约定。',expected=[dict(anchor='索引重建')]),
 dict(id='B03',text='明辰负责的证书轮换现转由许诺接手，明辰只继续提供资料；交付日改为2038-06-14。',expected=[dict(anchor='证书轮换',owner='许诺',deadline='2038-06-14')]),
 dict(id='B04',text='温禾承接镜像同步，下周五前交付，具体是哪天未写明。',expected=[dict(anchor='镜像同步',owner='温禾')]),
 dict(id='B05',text='许诺负责完成证书盘点，2038-06-20前交齐；再重复一遍：同一项证书盘点仍由许诺负责，日期不变。',expected=[dict(anchor='证书盘点',owner='许诺',deadline='2038-06-20')]),
 dict(id='B06',text='回滚演练确定执行；执行人和截止日均暂缺。这里只讨论如何补齐字段，演练本身已经定下。',expected=[dict(anchor='回滚演练')]),
 dict(id='B07a',text='雁栖项目：韩枫负责上线核查，2038-07-02交付。',expected=[dict(anchor='上线核查',owner='韩枫',deadline='2038-07-02',project='雁栖')]),
 dict(id='B07b',text='青禾项目：韩枫负责上线核查，2038-07-02交付。这是独立于雁栖项目的另一项工作。',expected=[dict(anchor='上线核查',owner='韩枫',deadline='2038-07-02',project='青禾')])]
jobs=[];gold=[]
for index,group in enumerate([cases[:4],cases[4:]]):
    source='\n'.join(f'[2038-05-0{i+1}T09:00:00Z] 纪要: '+c['text'] for i,c in enumerate(group))
    job=dict(id='synthetic-'+str(index+1),source=source,source_type='timestamped_text',qualification='DEV_DIAGNOSTIC')
    jobs.append(job)
    for ordinal,c in enumerate(group):
        gold.append(dict(job=job['id'],ordinal=ordinal,case_id=c['id'],expected=[dict(
            anchor=e['anchor'],owner=e.get('owner'),deadline=e.get('deadline'),
            project=e.get('project'),vendor=None) for e in c['expected']]))
data=WORK/'ami-public-gold-benchmark/work/ami-public-v1/data-04/inputs'
manifest=read(data/'manifest.json')
for meeting,limit in [('ES2002a',8),('ES2002b',3)]:
    original=data/f'transcripts/{meeting}.json'
    assert digest(original)==manifest['files'][f'transcripts/{meeting}.json']
    shutil.copyfile(original,out/f'{meeting}.json')
    transcript=read(original)
    for chunk in transcript['chunks'][:limit]:
        assert hashlib.sha256(chunk['text'].encode()).hexdigest()==chunk['sha256']
        jobs.append(dict(id=meeting+'-'+str(chunk['ordinal']),source=chunk['text'],
            source_type='manual_text',qualification='PUBLIC_TRANSCRIPT_DIAGNOSTIC_NO_EXHAUSTIVE_GOLD',
            meeting_id=meeting,chunk_id=chunk['chunk_id'],canonical_start=chunk['char_start'],
            canonical_end=chunk['char_end'],source_archive_sha256=transcript['archive_sha256'],
            source_transcript_sha256=digest(original),meeting_coverage='COMPLETE' if limit==len(transcript['chunks']) else 'PARTIAL_PREFIX_3_OF_18',
            utterance_spans=chunk['utterance_spans']))
save(out/'jobs.json',jobs);save(out/'diagnostic-expectations.json',gold)
save(out/'product-input.json',dict(id='B08',question='这两次记录的语料清点由谁承办，何时完成，任务如何延续？请给出原文。',
    source='[2038-08-01T09:00:00Z] 纪要: 语料清点确定执行，承办人和交付日仍未确定。\n[2038-08-03T09:00:00Z] 纪要: 接续前场的语料清点继续推进，负责人和交付日期依然未定。',
    expectation='Two work observations survive F and enter G; owner/deadline stay UNKNOWN. PARTIAL is acceptable, authoritative task approval is not expected.',qualification='DEV_DIAGNOSTIC'))
save(out/'manifest.json',dict(files={p.name:digest(p) for p in out.iterdir() if p.is_file()},
    AMI_selection='Complete ES2002a and canonical first 3 ES2002b chunks, before consulting Gold; ES2002b omitted chunks remain N/E',
    source_policy='Native text, speaker/relative-time headers and mappings retained; manual_text has no fabricated absolute event time',
    tasks_evaluation='Synthetic diagnostic expectations only; official AMI links are retrieval Gold, not exhaustive action-extraction labels'))
print('Frozen B:',len(jobs),'F jobs + one Product case; no Provider requests')
