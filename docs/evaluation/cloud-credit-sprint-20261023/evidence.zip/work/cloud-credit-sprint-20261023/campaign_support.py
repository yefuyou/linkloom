"""Telemetry around the existing TaskProviderSession/Adapter, never an Agent loop."""
from pathlib import Path
from datetime import datetime, UTC
import hashlib, importlib.metadata, json, os, sys, time
from urllib.request import Request,urlopen
from urllib.error import HTTPError

ROOT=Path(__file__).resolve().parent
CODE=ROOT/'candidate-code'
WORK=ROOT.parent
SHA='d0c64361ce0613d021d5d950954f7b0da6d2fabe'
sys.path[:0]=[str(CODE/'src'),str(CODE)]
from linkloom.agents.providers import GeminiProviderAdapter, build_gemini_sdk_client, GEMINI_38_FLASH_MODEL_ID
from linkloom.ui.task_provider import TaskProviderSession, TaskProviderLimits
from linkloom.semantic_ingestion.extraction import ProviderRequestAuthorization


def read(p): return json.loads(Path(p).read_text(encoding='utf8'))


def save(p,data):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf8') as f:
        json.dump(data,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())


def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def phase_root(phase): return WORK/('ce-'+phase.lower()+'-20261023')


def ledgers(phase):
    return sorted(WORK.glob('ce-'+phase.lower()+'-20261023*/provider/budget.json'))


def unresolved(path,ledger):
    pending=[a for a in ledger['attempts'] if a['outcome'] in {'PENDING','UNCERTAIN'}]
    if not pending:return False
    proof=path.parent.parent/'prewire-resolution.json'
    if not proof.exists():return True
    data=read(proof)
    if data.get('ledger_sha256')!=digest(path) or len(pending)!=1:return True
    a=pending[0];root=path.parent.parent
    if a['sequence']!=2 or data.get('sequence')!=2 or data.get('resolution')!='NOT_SENT_PREWIRE':return True
    request_path=root/'normalized/002-request.json'
    if data.get('request_sha256')!=digest(request_path):return True
    if sorted(p.name for p in (root/'wire').glob('*'))!=['001-request.json','001-response.json']:return True
    from linkloom.agents.model_adapter import ModelTurnRequest
    from linkloom.agents.providers.gemini_api import build_gemini_request
    request=ModelTurnRequest.from_dict(read(request_path))
    try:build_gemini_request(request,configured_model_id='gemini-4-argon')
    except Exception as error:
        return not (error.__class__.__name__=='_AdapterFailure' and error.details=={'reason':'temperature_unsupported_for_gemini_3'})
    return True


def client(base,path,*,method='GET',data=None):
    request=Request(base+path,method=method,data=None if data is None else json.dumps(data).encode('utf8'),
        headers={'Content-Type':'application/json'} if data is not None else {})
    try: response=urlopen(request,timeout=180)
    except HTTPError as error: response=error
    with response: return response.status,json.loads(response.read().decode('utf8'))


class Campaign:
    def __init__(self,phase,*,input_rate=1,output_rate=5,segment=None):
        self.phase=phase;self.root=phase_root(phase)
        if segment: self.root=self.root.with_name(self.root.name+'-'+segment)
        prior_paths=ledgers(phase)
        assert not prior_paths or segment, 'EXISTING_CAMPAIGN_NO_BUDGET_RESET'
        prior=[read(p) for p in prior_paths]
        assert all((p.parent.parent/'closed.json').exists() for p in prior_paths),'PRIOR_SESSION_NOT_CLOSED'
        assert all(not unresolved(p,b) for p,b in zip(prior_paths,prior))
        self.root.mkdir(exist_ok=False)
        self.plan=read(ROOT/'continuation_plan.json');config=self.plan[phase]
        self.wires=0
        remaining_seconds=config['max_seconds']
        if prior: remaining_seconds-= (datetime.now(UTC)-min(datetime.fromisoformat(b['started_at']) for b in prior)).total_seconds()
        assert remaining_seconds>65,'PHASE_TIME_EXHAUSTED'
        self.limits=TaskProviderLimits(config['max_requests']-sum(b['requests_reserved'] for b in prior),
            config['max_input_tokens']-sum(b['input_tokens_reserved'] for b in prior),
            config['max_output_tokens']-sum(b['output_tokens_reserved'] for b in prior),
            self.plan['new_allocations_usd'][phase]-sum(b['cost_reserved_usd'] for b in prior),
            remaining_seconds,65,config['reserve_each_usd'],input_rate,output_rate)
        self.validate()
        save(self.root/'authorization.json',dict(phase=phase,plan=self.plan,code_sha=SHA,
            sdk=importlib.metadata.version('google-genai'),python=sys.version,
            script_sha256=digest(__file__),code_zip_sha256=digest(ROOT/'candidate-code.zip'),
            prior_ledgers={str(p):digest(p) for p in prior_paths},new_experiments_only=bool(segment),
            started_at=datetime.now(UTC).isoformat(),actual_bill_usd=None))
        self.session=TaskProviderSession(self.root/'provider',self.limits,self.validate)
        self.sdk=build_gemini_sdk_client(os.environ['GEMINI_API_KEY'],
            http_options_kwargs=dict(timeout=60000,retry_options=dict(attempts=1)))
        campaign=self
        class Bridge:
            def generate_content(self,**wire): return campaign.wire(**wire)
        self.bridge=Bridge();real=GeminiProviderAdapter(self.bridge,model_id=GEMINI_38_FLASH_MODEL_ID)
        class RecordedAdapter(GeminiProviderAdapter):
            def complete(self,request):
                i=campaign.session.requests+1
                path=campaign.root/f'normalized/{i:03}-request.json'
                if not path.exists(): save(path,request.to_dict())
                response=campaign.session.complete(real,request.agent_id,request)
                p=campaign.root/f'normalized/{i:03}-response.json'
                if not p.exists(): save(p,response.to_dict())
                print(json.dumps(dict(phase=phase,request=i,stage=request.agent_id,
                    reserved_usd=round(campaign.session.cost,6),failure=campaign.session.failure)),flush=True)
                return response
        self.provider=RecordedAdapter(self.bridge,model_id=GEMINI_38_FLASH_MODEL_ID)

    def validate(self):
        if datetime.now(UTC)>=datetime.fromisoformat(self.plan['conservative_expiry_utc']):
            raise RuntimeError('CREDIT_DATE_STOP')
        if (ROOT/'STOP').exists(): raise RuntimeError('OPERATOR_STOP')
        assert sum(self.plan['new_allocations_usd'].values())+3<=min(95,self.plan['credit_confirmed_usd']-10)
        prior=2.4
        for p in [p for x in 'BCDE' for p in ledgers(x)]:
            if p.exists():
                ledger=read(p);prior+=ledger['cost_reserved_usd']
                if p.parent.parent!=self.root and unresolved(p,ledger):
                    raise RuntimeError('PRIOR_CAMPAIGN_PENDING_OR_UNCERTAIN_STOP')
        assert prior<=min(95,self.plan['credit_confirmed_usd']-10)

    def wire(self,**wire):
        self.wires+=1;i=self.wires
        save(self.root/f'wire/{i:03}-request.json',dict(**wire,sent_at=datetime.now(UTC).isoformat()))
        start=time.monotonic()
        try:
            response=self.sdk.models.generate_content(**wire)
            save(self.root/f'wire/{i:03}-response.json',dict(response=response.model_dump(mode='json'),
                latency_ms=(time.monotonic()-start)*1000,received_at=datetime.now(UTC).isoformat()))
            return response
        except Exception as exc:
            save(self.root/f'wire/{i:03}-error.json',dict(exception_type=type(exc).__name__,
                status_code=getattr(exc,'code',None),latency_ms=(time.monotonic()-start)*1000))
            raise

    def guard(self,request):
        return ProviderRequestAuthorization.approve(request,guard_id='credit-'+self.phase,
            reservation_id='credit-'+self.phase+'-'+str(self.session.requests+1),
            estimated_cost_upper_bound_usd=self.limits.request_cost_upper_bound_usd)

    def close(self):
        self.sdk.close()
        save(self.root/'closed.json',dict(requests=self.session.requests,wire_requests=self.wires,
            reserved_usd=self.session.cost,failure=self.session.failure,actual_bill_usd=None))
