"""Reuse M3-S2 F runner and M3-Q Product HTTP seams, no second Agent loop."""
from pathlib import Path
import argparse,json,sys,time
from campaign_support import ROOT,CODE,Campaign,read,save,digest,client
from linkloom.semantic_ingestion.artifacts import RawArtifact
from linkloom.semantic_ingestion.document_text import parse_source_text
from linkloom.semantic_ingestion.extraction import ProviderNeutralSemanticExtractor,TaskDiscoveryProfile
from linkloom.semantic_ingestion.task_observation_discovery import TaskObservationDiscoveryService
from linkloom.decision_memory.sources import SourceReferenceRegistry
from linkloom.agents.providers import GEMINI_38_FLASH_MODEL_ID
from linkloom.ui.product import ProductApplication
from linkloom.ui.task_provider import compose_task_provider,TaskProviderLimits
from tests.m3p_support import product_http

sys.stdout.reconfigure(encoding='utf8')
inputs=ROOT/'b-inputs';manifest=read(inputs/'manifest.json')
assert all(digest(inputs/k)==v for k,v in manifest['files'].items())
parser=argparse.ArgumentParser();parser.add_argument('--unattempted',action='store_true');args=parser.parse_args()
attempted=set()
if args.unattempted:
    from campaign_support import phase_root
    attempted={r['id'] for r in read(phase_root('B')/'cases-summary.json') if r['status']!='NOT_RUN'}
campaign=Campaign('B',segment='unattempted' if args.unattempted else None);rows=[]
save(campaign.root/'fixed-input-manifest.json',manifest)
try:
    for job in read(inputs/'jobs.json'):
        if job['id'] in attempted:
            rows.append(dict(id=job['id'],status='PRESERVED_PRIOR_FAILURE_NOT_RETRIED'));continue
        if campaign.session.failure:
            rows.append(dict(id=job['id'],status='NOT_RUN',reason=campaign.session.failure));continue
        artifact=RawArtifact('credit-b-public',job['id'],job['source_type'],job['source'])
        registry=SourceReferenceRegistry()
        for segment in parse_source_text(artifact).segments:
            registry.register_evidence(artifact.workspace_id,segment.evidence_span.evidence_ref,
                content_hash=artifact.content_hash,source_version=artifact.artifact_version_id)
        extractor=ProviderNeutralSemanticExtractor(campaign.provider,provider_id='gemini',
            model_id=GEMINI_38_FLASH_MODEL_ID,request_guard=campaign.guard,request_guard_id='credit-B',
            max_attempts=1,max_output_tokens=8192)
        before=campaign.session.requests;start=time.monotonic()
        result=TaskObservationDiscoveryService(extractor,source_registry=registry,
            current_source=lambda ws,aid:artifact,task_profile=TaskDiscoveryProfile.TASK_RECALL_V3).discover((artifact,),workspace_id=artifact.workspace_id)
        observations=(*result.valid_observations,*result.partial_observations)
        assert all(o.verify(artifact) for o in observations)
        row=dict(id=job['id'],qualification=job['qualification'],source_snapshot=job,
            artifact_version_id=artifact.artifact_version_id,content_hash=artifact.content_hash,
            discovery=result.to_dict(),requests=campaign.session.requests-before,
            elapsed_seconds=time.monotonic()-start,observation_count=len(observations),
            status='EXTRACTION_FAILED' if any(x.failure_code for x in result.extractions) else 'EXECUTED')
        save(campaign.root/f'cases/{job["id"]}.json',row);rows.append({k:v for k,v in row.items() if k not in {'discovery','source_snapshot'}})
        print(json.dumps(rows[-1],ensure_ascii=False),flush=True)
    scene=read(inputs/'product-input.json')
    if not campaign.session.failure:
        root=campaign.root/'product';root.mkdir()
        app=ProductApplication(database_path=root/'product.sqlite',extractor=None)
        service=compose_task_provider(app,campaign.provider,TaskProviderLimits(10,500000,65000,3,420,65,.25))
        try:
            with product_http(app,service) as base:
                _,body=client(base,'/api/workspaces',method='POST',data={'name':'Credit B08 public'})
                ws=body['workspace']['workspace_id'];client(base,'/api/workspaces/current',method='POST',data={'workspace_id':ws})
                _,body=client(base,'/api/sources/import',method='POST',data=dict(name='B08.txt',content=scene['source']))
                save(root/'source-import.json',body)
                _,config=client(base,'/api/product/ask/config')
                before=campaign.session.requests;start=time.monotonic()
                status,body=client(base,'/api/product/ask',method='POST',data=dict(query=scene['question'],workspace_id=ws,
                    allow_external_provider=True,investigation_context=dict(domain='tasks',snapshot_hash=config['investigation_context']['snapshot_hash'])))
                save(root/'submission.json',dict(http_status=status,body=body));result=body.get('result',{})
                end=time.monotonic()+430
                while result.get('status')=='INVESTIGATING' and time.monotonic()<end:
                    time.sleep(.4);_,body=client(base,f'/api/product/ask/runs/{result["agent_run_id"]}?workspace_id={ws}');result=body['result']
                save(root/'result.json',result)
                row=dict(id='B08',status=result['status'],requests=campaign.session.requests-before,
                    elapsed_seconds=time.monotonic()-start,reviewer=result['reviewer'])
                rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
        finally: app.close()
    else: rows.append(dict(id='B08',status='NOT_RUN',reason=campaign.session.failure))
finally:
    save(campaign.root/'cases-summary.json',rows);campaign.close()
