"""Existing M3-R SemanticProposer runner with unchanged public M2 contexts."""
from campaign_support import ROOT,CODE,Campaign,read,save,digest,phase_root
from tests.task_semantic_support import context_for
from linkloom.semantic_ingestion.task_relation_semantic_proposer import SemanticProposer
from linkloom.semantic_ingestion.task_relation_semantic_validation import validate_proposals
from linkloom.agents.providers import GEMINI_38_FLASH_MODEL_ID
import sys

sys.stdout.reconfigure(encoding='utf8')
inputs=ROOT/'c-inputs';manifest=read(inputs/'manifest.json')
assert all(digest(inputs/k)==v for k,v in manifest['files'].items())
campaign=Campaign('C',segment='resume' if '--resume' in sys.argv else None);rows=[]
save(campaign.root/'fixed-input-manifest.json',manifest)
# One campaign reservation layer only: proposer binds the underlying normalizer,
# while the recorded provider owns the existing TaskProviderSession boundary.
proposer=SemanticProposer(campaign.provider,model_id=GEMINI_38_FLASH_MODEL_ID,
    request_guard=campaign.guard,guard_id='credit-C')
try:
    for case in read(inputs/'cases.json'):
        if campaign.session.failure:
            rows.append(dict(id=case['case_id'],status='NOT_RUN',reason=campaign.session.failure));continue
        try:
            context=context_for(case)
            result=proposer.propose(context)
            row=dict(id=case['case_id'],qualification='DEV_DIAGNOSTIC',source_snapshot=case,
                status=result.status,errors=list(result.errors),provider_calls=result.provider_calls,
                elapsed_ms=result.elapsed_ms,usage=result.usage.to_dict(),provider_response_id=result.provider_response_id,
                proposals=[p.to_dict() for p in result.proposals],
                validation=[v.to_dict() for v in validate_proposals(result,context)],
                public_output=result.untrusted_output,lifecycle_limit=case.get('lifecycle_limit'),
                existing_expected=case.get('existing_expected'))
            row['verdicts']=[p.proposed_verdict for p in result.proposals]
        except Exception as exc:
            row=dict(id=case['case_id'],status='PREPARATION_FAILED',exception_type=type(exc).__name__,provider_calls=0)
        save(campaign.root/f'cases/{case["case_id"]}.json',row)
        brief={k:v for k,v in row.items() if k in {'id','status','errors','verdicts','provider_calls','exception_type'}}
        rows.append(brief);print(brief,flush=True)
finally:
    save(campaign.root/'cases-summary.json',rows);campaign.close()
