# 真实模型预检结果 — 2026-10-23（北京时间）

Batch A 完成三条有界 Product LIVE，16 次真实 Gemini 请求。两条完整链路返回
PARTIAL，一条保留为 G 准备阶段 BLOCKED。没有把 PARTIAL、未知字段或未确认关系
改成成功业务结论。其余批次没有发起付费请求。

**Token 费率估算 USD 0.11921025；费用预留 USD 2.40；实际账单金额 UNKNOWN。**
赠金可用已得到用户确认；本轮扣减后的 Console 页面只返回导航壳，未取得余额行。
因此尚未满足用户要求的“确认本轮赠金扣减后继续 B”的门槛。预检前刷新所见为
USD 139.34 / 150，2026-10-24 到期。本轮没有购入 Prepay、启用 Auto-reload、
调整信用卡、修改平台预算或启动后台付费任务。

## 结果表

| 案例 / 代码 | 请求 | 耗时 | F | G / Runtime / Reviewer | 产品结果 |
| --- | ---: | ---: | --- | --- | --- |
| A01 明确修订 / master `46b819fa…` | 7 | 44.09s | 两条任务；闻夏；2月16日/20日；原文字段可重验 | G 接受；三工具真实执行；Reviewer 接受回执 | PARTIAL |
| A02 歧义 / 同一 master | 2 | 13.91s | 两条任务；负责人/截止日均 UNKNOWN | 初始 G 返回后，重规划在本地 INPUT_BUDGET_EXCEEDED；Runtime/Reviewer N/E | BLOCKED |
| A03 同一歧义原文 / M3-D + Answer-first `d0c64361…` | 7 | 40.02s | 两条任务；负责人/截止日仍 UNKNOWN | G 接受；三工具真实执行；Reviewer 接受回执 | PARTIAL |

A02 与 A03 的来源 SHA256 均为
`aaa627070219888e9214db52cfbba1b3ddbac73d9a22f4556b1268c588f79113`。
A03 是已存在修复版本的一次诊断对照；未修改案例、生产代码或历史结果，不是失败
请求重试。没有重复调用已完成的明确案例。

master 精确 SHA：`46b819fa39ace26de2c5470f7438b56df523c560`，经 GitHub
`ls-remote` 核对。该 master 已合并 M3-Q/R/S，尚未包含 M3-D/S1/S2/Answer-first。
候选精确 SHA：`d0c64361ce0613d021d5d950954f7b0da6d2fabe`，本地干净。
其 M3-D 基础为 `33390e2eeaad71d215e279b2f724cae672ea4f80`。
两份不可变 Git ZIP 均保留，本报告不宣称候选已合并 master 或通过新的远端 CI。

## 真实验证到的语义与工程边界

- **F 字段解释有真实证据**：三次 F 返回六条观察。明确案例保留两个会议的任务、
  负责人及不同截止日；两个歧义版本均没有把报进度者、会议日期和未定交付选项落为
  确认字段。六条观察的原文、内容 hash、quote hash、offset 及全部字段来源切片
  均离线精确重验。这是两个已见开发案例的诊断，不是任务召回率或独立泛化分数。
- **G 已真实执行，但路径覆盖有限**：A01/A03 有可执行调查计划。A02 暴露 master
  的有界重规划输入问题；A03 的模型直接选 inspect/relation/clarify，未再次触发
  discover→UNKNOWN→replan，因此不能用 A03 声称该真实分支已验证通过。
- **SemanticAnalysis 确有两次新 Provider 调用**：各运行均为 cache_hit=false、
  new_live_provider_requests=1；由实际 Runtime 工具 analyze_task_semantics 发出。
  A01 SAME_TASK=SUPPORTED、REVISES_PLAN=SUPPORTED；A03 SAME_TASK=SUPPORTED、
  REVISES_PLAN=REFUTED。修订提案端点均为后会议→前会议，引用 EVIDENCE_VALID。
  A03 的反证是“均未定案、只是讨论选项”。这些模型解释与案例相符，但四个判断
  不能变成总体准确率，正反证冲突、错误合并等专项尚未新增评测。
- **Reviewer 目前证明工程链路**：accepted / evidence_sufficient 检查来源、生命周期、
  执行和回执，检查项明确含 SEMANTIC_NOT_EVALUATED；没有独立认定模型语义正确。
  所有模型提案仍 SUPPORTING_ONLY / MODEL_PROPOSED、publishable=false，未产生 P4
  批准或可信“延期4天”。COMPLETE coverage 采用来源版本合同，不能当成逻辑充分性。
- **实际 Product 冷读可复现**：新 Host 未配置 Provider，正常 Ask 重新核验 A03，
  UI 显示两条原文、未知负责人/截止日、模型倾向与正式业务状态待确认。查看来源
  的文本与冻结输入逐字相同，刷新回读成功，浏览器日志为空。截图和 DOM 均保留。
  唯一 fixture 引导复用原 verify_m3s_cold.py 的 sessionStorage 指针做法；实际
  Product 渲染、HTTP、来源重验和 Reviewer 没有替换。无额外模型调用。

全部案例资格为 **DEV_DIAGNOSTIC**。M2 H01–H04 与 M3-S H01–H03 是不同编号；
两者都已参与开发，不得作为本轮独立测试集。M2 历史 0/4 FAIL 保持原样。

## Token、费用和上限

模型 `gemini-3.8-flash`，16 份回执的 actual model version 相同；
`google-genai 2.22.0`，Python 3.13.5。F/G/语义使用其既有 thinking 配置；Runtime
未强行更改生产配置，逐请求实际 config 均已保存。

| 项目 | 数值 |
| --- | ---: |
| F / G / Runtime / Semantic | 3 / 3 / 8 / 2 |
| Provider SUCCEEDED / FAILED / UNCERTAIN | 16 / 0 / 0 |
| 输入 Token | 117,767 |
| 候选输出 Token | 6,509 |
| 已报告思考 Token | 1,727 |
| SDK total Token | 126,003 |
| SDK wire 延迟合计 | 91.13s |
| 费率计算 | USD 0.11921025 |
| 请求前持久预留 | USD 2.40 / 3 |

8 份思考计数字段为 null，原值保留；其余 total 与 prompt/candidate/thought 计数
可对账。计算输出费用时使用 max(candidate+reported thoughts, total-prompt)。
采用[官方 Standard 费率](https://ai.google.dev/gemini-api/docs/pricing)：
输入 USD .75/百万、输出含思考 USD 3.75/百万（当前优惠至 2026-12-31）。
没有服务器缓存、搜索、Maps、媒体或其他工具费用声明；这项计算不含税、不等于
已核实扣费，更不能把未取得账单当成 USD 0。

两阶段共用 A 的 20 请求 / USD 3 / 1,200,000 输入预留 / 160,000 输出预留上限。
A03 启动前扣除 A01/A02 已占用的 9 请求、USD 1.35 及 Token，并继承原 900 秒
起算时间。SDK attempts=1；请求前 fsync，超时/失败/不明/过期/预算耗尽立即停发。
没有多 Agent 并发调用或重新计零预算。未使用剩余 USD .60 预留空间制造请求。

## B–E 的状态与资料资格

| 批次 | 本轮状态 | 可复用资料 / 下一道门槛 |
| --- | --- | --- |
| B 抽取专项 | NOT_RUN；新增请求0 | M3-S 16组、M3-S2 12组已有真实证据；优先补多任务同句、重复任务、同文不同工作身份及进入G的诊断，避免无变化复跑。AMI 原始转录/映射已准备。需先完成账单门槛及冻结新批次预算。 |
| C 跨会议语义 | NOT_RUN；新增请求0 | M2 H01–H04、M3-R 7组关系困难案例均 DEV_DIAGNOSTIC；不改旧分数，不把已见案例当独立测试。重点应是方向、冲突和错误合并。 |
| D 强模型 Silver | NOT_RUN；新增请求0 | B/C 尚未开始；尚未验证较强模型接口，不声称不可用。验证后结果只能 MACHINE_SILVER；不能以模型一致代替Gold。 |
| E Compaction | NOT_RUN；新增请求0 | 前面批次未完成，未引入 LLM Compactor、修改 Runtime 或扩大生产上下文。 |

AMI 可用准备物位于 `../ami-public-gold-benchmark/work/ami-public-v1/data-04/`。
官方归档 SHA256 为 `b56e5babb2496b8795deeeda7e71178d7fbc9963f94276cf2a3f4b56ebbc9f9d`。
8 会议、6,981 DA、56 查询，其中 51 eligible、5 N/E。来源为 AMI Consortium /
University of Edinburgh 的人工摘要及官方 summary→DA 链接，CC BY 4.0。
**PUBLIC_HUMAN_GOLD 只适用于该官方链接检索协议**；标签不穷尽所有任务，未链接
片段也不是负例，不可直接报告任务抽取 recall/precision。ES2002 是开发，ES2005
已暴露为诊断，两者均为 AMI SA train。相对秒数不能伪装成真实绝对日期。

## 复现与文件

- `master-code.zip` / `candidate-code.zip`：固定代码与既有 Runner 依赖。
- `batch-a/` / `a3/`：来源、完整 SDK wire、归一化请求/响应、ID、Token、延迟、预算、
  Product SQLite、F/G 准备、Runtime 工具与 Reviewer 产物、每条失败/UNKNOWN。
- `analysis-final/aggregate.json`、`requests.json`、`cases.csv`：复算与逐案例汇总。
- `cold-unknown.jpg`、`cold-source.jpg`、`cold-*-dom.txt`：实际无模型浏览器证据。
- `cold-integrity.json`：206 个初次归档文件均存在；除两个 SQLite 运行缓存被新 Host
  打开后变化，其他来源/请求/回复/Runtime/Provider预算文件未改。SQLite 是可变运行
  状态；不把其初始 manifest hash 当作冷读后仍不变的证明。
- `billing-after-dom.txt` / `billing-after.jpg`：扣减后回读未完成的实际页面证据。

离线重新计算（不使用网络，不调用模型，使用新的输出目录）：

```powershell
D:/Anaconda/python.exe work/cloud-credit-sprint-20261023/analyze_batch_a.py --output work/cloud-credit-sprint-20261023/analysis-reproduce-01
```

付费 Runner 默认仅展示计划；`--execute` 才发送，已有输出目录拒绝重用。
`run_batch_a_master.py` 保留前两条运行时的精确脚本；`run_batch_a.py` 保留版本对照
选项，每次 authorization 记录脚本/归档 hash。**不要直接另建目录重跑来绕过预算**；
当前 A 已关闭，后续执行仍受本轮总账、赠金扣减和独立批次预算约束。

离线验证：既有预算/回执测试 17 PASS；候选组合与歧义 Product 合同 9 PASS。
首次误用不存在的测试文件，随后深临时目录导致 8 FAIL/1 PASS，保留 XML；改用短
项目目录后同一9项通过，没有改断言或生产代码。不是首次全绿或远端 CI PASS。

## 最值得解决的三个问题

1. **统一后续评测代码基线并覆盖真实重规划分支**：master 仍复现已知输入预算问题，
   候选的成功执行未触发重规划；不能把合成离线分支或直接计划成功当作该分支LIVE通过。
2. **建立任务级召回与身份诊断资格**：多任务、重复、换负责人、同文不同工作身份及
   Discovery→G 丢失需逐阶段计数；AMI 官方检索标签不能冒充完整抽取 Gold。
3. **把语义独立复核与引用正确分开衡量**：Reviewer 的工程 PASS 尚未检测错误身份
   合并、修订方向、冲突覆盖或未证实关系。应增加有限独立判断证据，保持 P4 门槛。

本轮没有修改 README 成绩、历史 Gold、生产代码、真实 vault、Git 分支、远端或 PR。
主工作区已有未提交开发材料全部保留。新增材料保留在本工作目录，未做删除清理。
