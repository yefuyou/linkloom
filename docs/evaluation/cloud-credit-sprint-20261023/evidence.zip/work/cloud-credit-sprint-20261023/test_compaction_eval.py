from dataclasses import replace
from compaction_eval import build_state,reader_request
from linkloom.context.working import compact_working_context,CompactionProposal
from linkloom.runtime.context_engineering import ContextRuntimeConfig,FakeHistoryCompactor
from linkloom.agents.providers.gemini_api import build_gemini_request

def test_bounded_real_history_and_protected_state_recovery():
    state,recovery,source=build_state();policy=ContextRuntimeConfig().policy
    restored=recovery.restore(workspace_id=state.workspace_id,refs=state.evidence_refs)
    assert restored.status=='complete' and len(restored.evidence)==2
    assert sum(len(o.encode()) for o in state.operations)>16000
    for compactor in (FakeHistoryCompactor(),):
        result=compact_working_context(state,compactor=compactor,recovery=recovery,max_tokens=4096,policy=policy)
        assert result.status=='complete' and result.state.unresolved_questions==state.unresolved_questions
        assert result.state.evidence_refs==state.evidence_refs and result.after_bytes<result.before_bytes
        assert result.recovery.evidence==restored.evidence
        build_gemini_request(reader_request(result.state,result.recovery))
    payload=build_gemini_request(reader_request(state,restored))
    assert payload['model']=='gemini-3.8-flash'
