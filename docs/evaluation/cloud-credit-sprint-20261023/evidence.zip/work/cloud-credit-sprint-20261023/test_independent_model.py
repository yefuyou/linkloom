from types import SimpleNamespace
from pathlib import Path
import pytest
from campaign_support import CODE
from linkloom.agents.providers import GeminiProviderAdapter
from linkloom.agents.model_adapter import ModelTurnRequest,ModelGenerationOptions
from linkloom.tools.contracts import ToolDefinition
from linkloom.ui.task_provider import TaskProviderSession,TaskProviderLimits
from independent_model import IndependentSDKAdapter
from dataclasses import replace


def test_silver_truthful_model_metadata_budget_and_product_boundary(tmp_path):
    calls=[]
    def wire(**payload):
        calls.append(payload)
        return dict(candidates=[dict(content=dict(role='model',parts=[dict(function_call=dict(name='emit_probe',args=dict(status='ok')))]),finish_reason='STOP')],
            usage_metadata=dict(prompt_token_count=10,candidates_token_count=5,total_token_count=15),
            model_version='gemini-4-argon',response_id='silver-offline-response')
    session=TaskProviderSession(tmp_path/'provider',TaskProviderLimits(1,20000,1024,.5,30,10,.5,2,10),lambda:None)
    campaign=SimpleNamespace(root=tmp_path,session=session,wire=wire,
        bridge=SimpleNamespace(generate_content=wire))
    adapter=IndependentSDKAdapter(campaign,'gemini-4-argon')
    tool=ToolDefinition('emit_probe','1','Return the probe',dict(type='object',properties=dict(status=dict(type='string')),required=['status'],additionalProperties=False),dict(type='object'))
    request=ModelTurnRequest('silver-run','t1','task','silver',1,'Public synthetic protocol probe',None,[tool],
        model_id='gemini-4-argon',generation_options=ModelGenerationOptions(max_output_tokens=512,require_tool_call=True,thinking_level='low'))
    response=adapter.complete(request)
    assert response.error is None and response.action.tool_call.arguments==dict(status='ok')
    assert response.provider_metadata['model']=='gemini-4-argon'
    assert response.provider_metadata['model_version']=='gemini-4-argon'
    assert response.provider_response_id=='silver-offline-response'
    assert calls[0]['model']=='gemini-4-argon'
    assert adapter.complete(request).error is not None and len(calls)==1
    # No widening of the normal Product's explicit model allow-list.
    with pytest.raises(Exception): GeminiProviderAdapter(campaign.bridge,model_id='gemini-4-argon')


def test_pre_wire_invalid_options_are_known_failure():
    calls=[]
    wire=lambda **payload:calls.append(payload)
    campaign=SimpleNamespace(bridge=SimpleNamespace(generate_content=wire),wire=wire)
    adapter=IndependentSDKAdapter(campaign,'gemini-4-argon')
    request=ModelTurnRequest('prewire','turn','task','silver',1,'Public input',None,[],model_id='gemini-4-argon',
        generation_options=ModelGenerationOptions(max_output_tokens=512,temperature=0))
    response=adapter.invoke(request)
    assert response.error.code=='MODEL_INVALID_REQUEST'
    assert response.error.outcome=='known_failure' and calls==[]
