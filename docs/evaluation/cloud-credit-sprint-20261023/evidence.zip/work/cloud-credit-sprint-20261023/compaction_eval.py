"""Evaluation-only injectable Compactor; no Agent loop or Runtime mutation."""
from dataclasses import replace,asdict
from datetime import datetime,UTC
from pathlib import Path
import hashlib,json
from campaign_support import ROOT,WORK,read,save,digest
from linkloom.context.models import ContextResource,ResourceType
from linkloom.context.recovery import SourceSnapshot,EvidenceRef,EvidenceRecovery
from linkloom.context.working import WorkingContext,RecordRef,CompactionProposal
from linkloom.agents.model_adapter import ModelTurnRequest,ModelGenerationOptions
from linkloom.agents.providers import GEMINI_38_FLASH_MODEL_ID
from linkloom.tools.contracts import ToolDefinition

def encode(value):return json.dumps(value,ensure_ascii=False,separators=(',',':'))

def build_state():
    transcript=read(ROOT/'b-inputs/ES2002a.json');text=transcript['canonical_text']
    ws='credit-e-public';now=datetime(2026,10,23,tzinfo=UTC)
    resource=ContextResource(ws,'ami-source','ES2002a','/AMI/ES2002a.txt','/AMI',1,now,
        hashlib.sha256(text.encode()).hexdigest(),'ami://ES2002a/canonical',ResourceType.DOCUMENT,now,1)
    source=SourceSnapshot(resource,text)
    discovery=read(WORK/'ce-b-20261023-unattempted/cases/ES2002a-6.json')['discovery']
    observation=(discovery['valid_observations']+discovery['partial_observations'])[0]
    anchor=observation['description'];start=text.index(anchor)
    # Fixed source neighborhoods, no model or Gold-derived correctness labels.
    spans=[(max(0,start-350),min(len(text),start+700)),
           (transcript['chunks'][7]['char_start'],min(len(text),transcript['chunks'][7]['char_start']+1000))]
    refs=tuple(EvidenceRef.from_snapshot(source,a,b) for a,b in spans)
    questions=(f'Unconfirmed unfinished work: {anchor}. Completion is UNKNOWN.',
        'Owner identity and absolute deadline require source confirmation; preserve UNKNOWN if absent.')
    # The history is a declared replay of native retrieved chunks, not a claim
    # that production Runtime has already produced these retrieval receipts.
    operations=tuple('UNTRUSTED_RETRIEVAL_HISTORY_REPLAY\n'+c['text'] for c in transcript['chunks'][5:8])
    h=digest(ROOT/'b-inputs/ES2002a.json')
    state=WorkingContext(workspace_id=ws,run_id='credit-e',user_goal='Retain pending work and exact necessary source evidence through operational compaction.',
        ledger_ref=RecordRef(ws,'credit-e','ledger','b-inputs/ES2002a.json',h),
        checkpoint_ref=RecordRef(ws,'credit-e','checkpoint','ce-b-20261023-unattempted/cases/ES2002a-6.json',digest(WORK/'ce-b-20261023-unattempted/cases/ES2002a-6.json')),
        unresolved_questions=questions,evidence_refs=refs,operations=operations,
        next_investigations=('Read fresh originals; source-bound proposal is not approved business truth.',))
    recovery=EvidenceRecovery(lambda workspace,identity:source if (workspace,identity)==(ws,resource.resource_id) else None,
        max_total_quote_bytes=24*1024)
    return state,recovery,source

def request(agent,user,tool_id,schema,output=2048):
    tool=ToolDefinition(tool_id,'1','Emit untrusted evaluation output only.',schema,dict(type='object'))
    return ModelTurnRequest('credit-e',agent,'task',agent,1,user,None,[tool],model_id=GEMINI_38_FLASH_MODEL_ID,
        generation_options=ModelGenerationOptions(max_output_tokens=output,require_tool_call=True,thinking_level='low'))

def arguments(response,tool_id):
    if response.error:raise RuntimeError(response.error.code)
    calls=[]
    if response.proposal is not None and response.proposal.kind=='tool_calls':calls=[c.runtime_call for c in response.proposal.tool_calls]
    elif response.action is not None and response.action.kind=='tool_call':calls=[response.action.tool_call]
    if len(calls)!=1 or calls[0].tool_id!=tool_id:raise RuntimeError('INVALID_SINGLE_EMITTER')
    return calls[0].arguments

class LLMHintCompactor:
    def __init__(self,adapter):self.adapter=adapter
    def compact(self,request_):
        ids=[r.evidence_id for r in request_.state.evidence_refs]
        schema=dict(type='object',properties=dict(summary_text=dict(type='string'),evidence_ids=dict(type='array',items=dict(type='string',enum=ids))),required=['summary_text','evidence_ids'],additionalProperties=False)
        prompt='Compress only operational retrieval history into <=450 words of untrusted hints. Preserve unfinished tasks, gaps and UNKNOWN. Never mark tasks completed or infer approval. Cite only supplied evidence IDs; summaries cannot replace original evidence.\n'+request_.state.render()
        result=arguments(self.adapter.complete(request('llm-compactor',prompt,'emit_compaction',schema)),'emit_compaction')
        if not isinstance(result.get('summary_text'),str) or not set(result.get('evidence_ids',[])).issubset(ids):raise RuntimeError('INVALID_COMPACTION_PROPOSAL')
        return CompactionProposal(result['summary_text'],tuple(result['evidence_ids']))

def reader_request(state,restored):
    ids=[e.ref.evidence_id for e in restored.evidence]
    citation=dict(type='object',properties=dict(evidence_id=dict(type='string',enum=ids),quote=dict(type='string')),required=['evidence_id','quote'],additionalProperties=False)
    schema=dict(type='object',properties=dict(pending_questions=dict(type='array',items=dict(type='string')),
        business_completion=dict(type='string',enum=['UNKNOWN']),citations=dict(type='array',items=citation)),
        required=['pending_questions','business_completion','citations'],additionalProperties=False)
    prompt='Repeat every protected unresolved question exactly. Preserve UNKNOWN business completion. For EVERY fresh original below return its evidence ID and an exact contiguous nonempty quote supporting the pending work or gap. Hints/history cannot substitute for fresh evidence.\nworking_context='+state.render()+'\nfresh_originals='+encode([dict(evidence_id=e.ref.evidence_id,quote=e.quote) for e in restored.evidence])
    return request('context-reader',prompt,'emit_context_check',schema,2048)
