"""Offline final integrity and cost-bound audit. No Provider calls."""
from campaign_support import ROOT,WORK,read,save,digest,ledgers,unresolved
from datetime import datetime,UTC
from zipfile import ZipFile
import importlib.metadata,sys

integrity={}
for archive,folder in [('master-code.zip','code'),('candidate-code.zip','candidate-code')]:
    with ZipFile(ROOT/archive) as z:
        names=[n for n in z.namelist() if not n.endswith('/')]
        failures=[n for n in names if not (ROOT/folder/n).is_file() or z.read(n)!=(ROOT/folder/n).read_bytes()]
    assert not failures,(archive,failures)
    integrity[archive]=dict(sha256=digest(ROOT/archive),files_verified=len(names),mismatches=failures)

ledger_checks=[]
plan=read(ROOT/'continuation_plan.json')
for phase in 'BCDE':
    phase_rows=[]
    for p in ledgers(phase):
        b=read(p);assert (p.parent.parent/'closed.json').exists() and not unresolved(p,b)
        limit=b['limits']
        assert b['requests_reserved']<=limit['max_requests']
        assert b['input_tokens_reserved']<=limit['max_input_tokens'] and b['output_tokens_reserved']<=limit['max_output_tokens']
        assert b['cost_reserved_usd']<=limit['max_cost_usd']+1e-9
        assert b['elapsed_seconds']<=limit['max_seconds']
        for attempt in b['attempts']:
            if attempt['outcome']=='SUCCEEDED':
                usage=attempt['usage'];assert usage['input_tokens']<=attempt['input_reserved']
                assert usage['output_tokens']<=attempt['output_reserved']
                assert usage['total_tokens']<=attempt['input_reserved']+attempt['output_reserved']
        phase_rows.append(b)
        ledger_checks.append(dict(path=str(p),sha256=digest(p),requests=b['requests_reserved'],cost_reserved_usd=b['cost_reserved_usd'],unresolved=False))
    assert sum(b['cost_reserved_usd'] for b in phase_rows)<=plan['new_allocations_usd'][phase]
    assert sum(b['requests_reserved'] for b in phase_rows)<=plan[phase]['max_requests']
    assert sum(b['input_tokens_reserved'] for b in phase_rows)<=plan[phase]['max_input_tokens']
    assert sum(b['output_tokens_reserved'] for b in phase_rows)<=plan[phase]['max_output_tokens']

aggregate=read(ROOT/'continuation-analysis-v2/aggregate.json')
assert aggregate['total']['reserved_usd']<min(95,plan['credit_confirmed_usd']-10)
assert aggregate['C_proposals']==20 and aggregate['C_quote_validation_failures']==1
assert aggregate['synthetic_model_candidates']==9 and aggregate['synthetic_admitted']==7
assert aggregate['D_equal']==4
e=read(ROOT/'continuation-analysis-v2/e-comparison.json')['readers']
assert len(e)==3 and all(r['pending_retained'] and r['necessary_evidence_coverage']==1 for r in e)
save(ROOT/'STOP',dict(reason='PLANNED_DIAGNOSTIC_EXPERIMENTS_COMPLETE_NO_ADDITIONAL_PROVIDER_CALLS',at=datetime.now(UTC).isoformat()))
save(ROOT/'final-qualification.json',dict(status='COMPLETED_WITH_PRESERVED_FAILURES_AND_NE',final_report='FINAL_REPORT.md',
    supersedes_for_current_status=['REPORT.md','qualification.json'],historical_files_preserved=True,
    code_integrity=integrity,ledger_checks=ledger_checks,unresolved_provider_outcomes=0,
    sdk=importlib.metadata.version('google-genai'),python=sys.version,
    semantic_qualifications=['DEV_DIAGNOSTIC','MACHINE_SILVER'],formal_extraction_gold='N/E_INCOMPATIBLE_LABEL_TASK',
    user_credit_authorization='REUSED_NO_NEW_BILLING_CONSOLE_READ',actual_bill_usd=None,promotional_deduction_usd=None,
    aggregate=aggregate['total'],test_evidence=['d-adapter-v2.xml','e-preflight.xml','candidate-contract-short-path.xml'],
    production_files_modified=False,README_scores_modified=False,commits_created=False,pushes_or_PR_actions=False))
allfiles=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts]
allfiles += [p for phase in 'BCDE' for root in WORK.glob('ce-'+phase.lower()+'-20261023*') for p in root.rglob('*') if p.is_file()]
save(ROOT/'complete-evidence-manifest.json',dict(generated_at=datetime.now(UTC).isoformat(),
    files={str(p.relative_to(WORK)):dict(sha256=digest(p),bytes=p.stat().st_size) for p in sorted(allfiles)},
    excludes=['Python cache and pytest cache only'],note='Manifest excludes itself; original historical manifest remains untouched.'))
print(dict(status='FINAL_INTEGRITY_PASS',archived_source_files=sum(v['files_verified'] for v in integrity.values()),
    ledgers=len(ledger_checks),files=len(allfiles),reserved_usd=aggregate['total']['reserved_usd'],all_sessions_closed=True))
