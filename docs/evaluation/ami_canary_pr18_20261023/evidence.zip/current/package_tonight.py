"""Immutable offline-blocked Canary evidence; never constructs a Provider."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,os,re,subprocess,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs/evaluation/ami_canary_pr18_20261023'
OUT.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf8'))
files=[]
for dirname in ['tonight-checks-01','tonight-replay-01','tonight-plan-01']:
    for p in (ROOT/'work'/dirname).rglob('*'):
        if p.is_file() and 'tmp-quote' not in p.parts:
            files.append((p,'current/'+p.relative_to(ROOT/'work').as_posix()))
for name in ['tonight-red.xml','tonight-red.log','tonight-green.xml','tonight-green.log',
             'tonight-diagnostic-contracts.xml','tonight-diagnostic-contracts.log','tonight-gate-refusal.log',
             'tonight-blocker-reproduction.json','tonight_blocker_repro.py','tonight-independent-review.md']:
    p=ROOT/'work'/name
    if p.exists():files.append((p,'current/'+name))
history=ROOT.parent/'ami-real-semantic-canary/docs/evaluation/ami_semantic_canary_v1/live'
seal=read(history/'output_seal.json')
for name,expected in seal['files'].items():assert sha((history/name).read_bytes())==expected
for p in history.rglob('*'):
    if p.is_file():files.append((p,'historical-pr16/live/'+p.relative_to(history).as_posix()))
inputs=ROOT.parent/'ami-public-gold-benchmark/work/ami-public-v1/data-04/inputs'
for name in ['manifest.json','transcripts/ES2002a.json','transcripts/ES2005c.json']:
    files.append((inputs/name,'inputs/'+name))
snapshot=ROOT/'work/tonight-source-693ab81.zip'
frozen=read(ROOT/'work/tonight-plan-01/plan.json')
if not snapshot.exists():
    with ZipFile(snapshot,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
        for name,expected in frozen['code_hashes'].items():
            data=(ROOT/name).read_bytes();assert sha(data)==expected,name
            z.writestr(name,data)
        z.writestr('pyproject.toml',(ROOT/'pyproject.toml').read_bytes())
        z.writestr('SOURCE_IDENTITY.json',json.dumps(dict(runner_sha=frozen['frozen_sha'],production_sha=frozen['production_sha'],
            code_hashes=frozen['code_hashes']),ensure_ascii=False,indent=2))
with ZipFile(snapshot) as z:
    assert all(sha(z.read(n))==h for n,h in frozen['code_hashes'].items())
files.append((snapshot,'source/runner-693ab81.zip'))
files.append((ROOT/'work/package_tonight.py','current/package_tonight.py'))
secrets=[v.encode() for k,v in os.environ.items() if re.search('(API_KEY|ACCESS_TOKEN|SECRET_KEY)$',k) and len(v)>=16]
index={}
with ZipFile(OUT/'evidence.zip','w',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for path,name in files:
        data=path.read_bytes();assert not any(s in data for s in secrets),name
        z.writestr(name,data);index[name]=dict(sha256=sha(data),bytes=len(data))
quote=ET.parse(ROOT/'work/tonight-checks-01/quote.xml')
failures=[dict(testcase=t.get('name'),classname=t.get('classname'),message=t.find('failure').get('message'))
          for t in quote.iter('testcase') if t.find('failure') is not None]
gate=dict(status='BLOCKED_OFFLINE_GATE',production_sha='ba51b3586135f1ef52a32b5e9945d14b058bac38',
    runner_sha='693ab81c134fcc3af76e4e1861a90f97a2bde734',source_snapshot_sha256=sha(snapshot.read_bytes()),
    quote_tests=dict(passed=143,failed=1,total=144,failures=failures),other_contracts_passed=162,
    historical_outputs_replayed=28,first_round_requests_identical=True,
    live=dict(provider_calls=0,smoke_calls=0,actual_reservation_usd=0,estimated_new_cost_usd=0,
        attempted_chunks=0,unattempted_chunks=28,status='N/E',reason='NESTED_QUOTE_SAFETY_GATE_FAILED'),
    plan=dict(meetings={'ES2002a':8,'ES2005c':20},profile=None,model='gemini-3.8-flash',max_output_tokens=4096,
        thinking='low',temperature=None,planned_reservation_usd=7,budget_limit_usd=8,runner_request_limit=30,user_request_ceiling=32,retries=0),
    production_changed=False,F_prompt_changed=False,Compactor_or_PR19_changed=False,independent_review='See archived review if present; otherwise NOT_VERIFIED')
for name,data in [('STATUS.json',gate),('EVIDENCE_MANIFEST.json',dict(archive_sha256=sha((OUT/'evidence.zip').read_bytes()),files=index,
    preserved_historical_seal=True,no_new_provider_receipts=True))]:
    with (OUT/name).open('w',encoding='utf8',newline='\n') as f:json.dump(data,f,ensure_ascii=False,indent=2)
print(dict(status=gate['status'],files=len(files),bytes=(OUT/'evidence.zip').stat().st_size,provider_calls=0))
