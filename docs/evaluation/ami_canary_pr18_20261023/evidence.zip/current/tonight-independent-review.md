# Tonight Canary independent review

Review scope: read-only review of the existing Runner checkout and tonight's
offline artifacts. No Provider, network, billing, prompt/compactor change,
production fix, expectation change, commit, or push was performed.

## Verdict

**BLOCKED: stop the real Canary.** The Quote gate failure is a real current
production behavior failure on the pinned PR18 source, and it is reproduced
independently. The mandatory Quote suite cannot be treated as passed because
the other 162 diagnostic contracts pass or because the fixed-output replay is
marked `PASS`.

## VERIFIED

1. **The supplied Quote gate is red.** `work/tonight-checks-01/quote.log.json`
   records the exact four-suite command, exit code `1`, and the failure
   `test_same_ascii_quote_pairs_support_a_nested_quoted_claim`. The companion
   `quote.xml` has 144 tests, 143 passes, 1 failure, and 0 errors/skips. The
   failure is at `tests/unit/test_canary_quote_scopes.py:95`.

2. **The failure reproduces offline from the current checkout.** With the
   checkout's `src` on `PYTHONPATH`, the exact test fails; the whole
   `test_canary_quote_scopes.py` file reports 1 failure and 19 passes. A direct
   call with the test text returns:

   ```text
   quoted_ranges(text) == [(4, 17), (23, 51)]
   work range == [17, 23)
   non_asserted(work) == False
   non_asserted(outer task) == True
   non_asserted(current task) == False
   ```

   Thus the inner work phrase is exposed between two split ASCII-quote ranges,
   exactly the condition the regression test is meant to reject. The pinned
   production file hash is
   `6fe06edb5330ec3dd78384026db205fc543b0c5dfc14aba252df90d2ba14eff1`.

3. **The blocker reproduction agrees with the direct result.**
   `work/tonight-blocker-reproduction.json` records `status=BLOCKED`, production
   SHA `ba51b3586135f1ef52a32b5e9945d14b058bac38`, Runner SHA
   `693ab81c134fcc3af76e4e1861a90f97a2bde734`, ranges `[(4,17),(23,51)]`,
   `expected_quoted_work_refused=true`, `non_asserted=false`, one scripted
   F-to-Discovery turn, one `PARTIAL` observation, zero valid observations,
   and `real_provider_calls=0`. The original PR18 P2 case remains
   `work_non_asserted=true`.

4. **The remaining offline diagnostic contracts pass.**
   `work/tonight-diagnostic-contracts.xml` records 162 tests, 0 failures,
   0 errors, and 0 skips. This confirms the Runner, UNKNOWN, permission, P4,
   and Reviewer contract evidence supplied for this round; it does not clear
   the separate red Quote suite.

5. **The null-profile request binding is verified.**
   `work/tonight-plan-01/plan.json` records Runner SHA
   `693ab81c134fcc3af76e4e1861a90f97a2bde734`, production SHA
   `ba51b3586135f1ef52a32b5e9945d14b058bac38`, profile `null`, 28 requests,
   `compactor=false`, 30-request/8-USD limits, one SDK/F attempt, and USD 7
   reserved. Its `planned_requests_sha256` is
   `7eb363fb366f574fb2f1169b643877c5d5f9b87b8e81450c8dc351ff8a965f64`.
   The independently computed canonical hash of the sealed historical
   `actual_requests.jsonl` is the same, all 28 parsed requests compare equal,
   and the raw actual-request bytes match the historical seal
   `aade2a5cc22a350e9f7b8b43529b7d3ce9fe492db7c4d4aa66ff9136253433ff`.

6. **The fixed-output replay is mechanically intact and provider-free.**
   `work/tonight-replay-01/replay_receipt.json` records `status=PASS`,
   `task_profile=null`, `provider_calls=0`, 28 replayed outputs, and complete
   8/20 meeting populations. `discovery.json` contains the expected ten
   batches and all 28 extraction records.

7. **The Runner production pin is effective.** The current Runner worktree was
   at `693ab81c134fcc3af76e4e1861a90f97a2bde734`. A read-only `git diff`
   against `ba51b3586135f1ef52a32b5e9945d14b058bac38` reports no differences
   under `src/linkloom` after excluding the explicitly allowed
   `src/linkloom/evaluation/canary_trust.py`. The reviewed Runner delta adds the
   production pin, the planned-request hash, the null-profile historical
   request/seal check, and the expanded Quote suite; it does not edit the
   pinned PR18 source.

## INFERRED

- The real Canary must stop before any Provider call. `prepare_canary_gate.py`
  rejects any JUnit report with failures, and the Quote report has one failure.
  Continuing would bypass the declared offline gate.
- The scripted `PARTIAL` is a useful propagation reproduction, not a semantic
  success or task-recall score. The quote veto is the prerequisite that is
  currently unsatisfied.
- The Runner's null-profile path preserves the historical F contract: the
  plan, model, prompt inputs, compactor setting, request population, and
  sealed `actual_requests` identity are bound before live execution. The
  source-tree pin separately protects the production code boundary.

## NOT_VERIFIED

- No live Provider call, network request, billing observation, or SDK wire
  receipt was made in this review. `real_provider_calls=0` is from the supplied
  offline artifact; this review does not prove an external account state.
- The replay is labeled `DEV_DIAGNOSTIC` with
  `INDEPENDENT_REVIEW_NOT_VERIFIED`; its summary has `discovery_valid=0`,
  `discovery_partial=4`, quote validation `4/5`, and semantic qualification
  `NOT_EVALUATED` with null precision/recall/F1. It cannot establish business
  accuracy or clear the Quote gate.
- No production repair was attempted, so there is no claim that the nested
  same-ASCII-quote behavior is fixed. The next run would need a separately
  reviewed production change, a fresh passing Quote gate, and a regenerated
  offline gate before any real Canary.

## Required summary wording

Report this round as **BLOCKED by an independently reproduced existing Quote
gate failure**. State that the 162 other contracts, the provider-free null
profile replay, and the 28-request/sealed-request identity checks passed their
own declared checks, while the mandatory Quote gate did not. Do not describe
the replay's PARTIAL observations as recovered tasks, and do not start
ES2002a/ES2005c live execution until the Quote gate is green.
