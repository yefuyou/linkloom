"""Offline exact nested-quote blocker, scripted F output only, no SDK client."""
from pathlib import Path
from datetime import datetime,UTC
import json,sys,hashlib,subprocess
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'tests/unit'),str(ROOT)]
from linkloom.semantic_ingestion.text_scopes import quoted_ranges,unquoted_text
from linkloom.semantic_ingestion.task_discovery_veto import non_asserted
from linkloom.semantic_ingestion.artifacts import RawArtifact
from tests.unit.test_task_observation_discovery import claim,setup

text="同事说：'outer says '安排部署任务' outer task remains inside'。当前任务已安排。"
work='安排部署任务';start=text.index(work)
artifact=RawArtifact('public-workspace','quote-blocker','manual_text',text,ingestion_time=datetime(2026,10,23,tzinfo=UTC))
service,provider,_,_=setup(artifact,[claim(work,work)])
result=service.discover((artifact,),workspace_id=artifact.workspace_id)
exact_p2='''He wrote: 'cause deliver the layout after reading "'Hello'" tomorrow.' '''.rstrip()
row=dict(status='BLOCKED',production_sha='ba51b3586135f1ef52a32b5e9945d14b058bac38',
    runner_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    text=text,work=work,work_start=start,work_end=start+len(work),
    quote_ranges=quoted_ranges(text),unquoted_text=unquoted_text(text),
    non_asserted=non_asserted(text,[work],start,start+len(work)),
    expected_quoted_work_refused=True,actual_discovery=result.to_dict(),
    scripted_provider_turns=len(provider.requests),real_provider_calls=0,
    original_pr18_p2=dict(text=exact_p2,quote_ranges=quoted_ranges(exact_p2),
        work_non_asserted=non_asserted(exact_p2,['deliver the layout'],17,35)),
    production_file_sha256=hashlib.sha256((ROOT/'src/linkloom/semantic_ingestion/text_scopes.py').read_bytes()).hexdigest())
out=ROOT/'work/tonight-blocker-reproduction.json'
with out.open('x',encoding='utf8',newline='\n') as f:json.dump(row,f,ensure_ascii=False,indent=2)
print({k:row[k] for k in ['quote_ranges','non_asserted','scripted_provider_turns','real_provider_calls','production_file_sha256']})
print('admitted',len(result.valid_observations)+len(result.partial_observations))
