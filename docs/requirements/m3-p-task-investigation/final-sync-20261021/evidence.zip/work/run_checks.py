"""Replay the committed offline CI commands, preserving raw output and receipts."""
import datetime
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'work' / (sys.argv[1] if len(sys.argv) > 1 else 'final-evidence')
OUT.mkdir(parents=True, exist_ok=True)
env = dict(os.environ, PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',
           PYTHONPATH=os.pathsep.join(['src', '.', 'tests/integration']),
           LINKLOOM_RETRIEVAL_MODE='bm25', GEMINI_API_KEY='', DEEPSEEK_API_KEY='',
           PYTHONIOENCODING='utf-8', TEMP=str(OUT), TMP=str(OUT))
workflow = yaml.safe_load((ROOT / '.github/workflows/offline-pr.yml').read_text())
receipts = []
for job in (sys.argv[2:] or ['core', 'task-investigation', 'legacy-temporal', 'frozen-ledger']):
    for index, step in enumerate(workflow['jobs'][job]['steps']):
        run = step.get('run', '')
        if 'python -m pytest ' not in run:
            continue
        args = shlex.split(run)
        args[0] = sys.executable
        args += ['--basetemp=' + str(OUT / ('tmp-' + job)), '--tb=short']
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (OUT / (job + '.log')).open('w', encoding='utf-8') as log:
            result = subprocess.run(args, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        receipts.append(dict(job=job, args=args, started=started,
                             finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                             exit_code=result.returncode))
        (OUT / 'checks.json').write_text(json.dumps(receipts, indent=2), encoding='utf-8')
        print(job, result.returncode, flush=True)
