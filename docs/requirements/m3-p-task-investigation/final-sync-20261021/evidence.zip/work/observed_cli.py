"""Test-only access timing around the unchanged Product HTTP handler and CLI."""
from datetime import datetime, timezone
import json
from time import monotonic
from linkloom.ui.server import LinkLoomRequestHandler
from linkloom.ui.__main__ import main

def timed(method):
    def handle(self):
        started = monotonic()
        try:
            return method(self)
        finally:
            print(json.dumps(dict(timestamp=datetime.now(timezone.utc).isoformat(),
                method=self.command, path=self.path, elapsed_ms=(monotonic()-started)*1000)), flush=True)
    return handle

LinkLoomRequestHandler.do_GET = timed(LinkLoomRequestHandler.do_GET)
LinkLoomRequestHandler.do_POST = timed(LinkLoomRequestHandler.do_POST)
raise SystemExit(main())
