"""Archive only this run's public synthetic evidence; exclude dependency caches."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root = Path.cwd()
target = root / 'docs/requirements/m3-p-task-investigation/final-sync-20261021'
target.mkdir(parents=True, exist_ok=True)
shots = {
    'browser-a/01-task-review.png':'task-review.png',
    'browser-a/02-exact-source.png':'exact-source.png',
    'browser-a/04-refreshed-revalidated.png':'refreshed-revalidated.png',
    'browser-a/07-responsive-390.png':'responsive-390.png',
    'browser-c/01-valid-approval.png':'valid-approval.png',
    'browser-c/02-decision-memory.png':'decision-memory.png',
    'browser-c/03-current-ask.png':'current-ask.png',
    'browser-c/04-historical-ask.png':'historical-ask.png',
    'browser-c/05-unresolved-relation.png':'unresolved-relation.png',
    'browser-c/06-review-attention.png':'review-attention.png',
    'no-provider-saved.png':'no-provider-saved.png',
}
for original, name in shots.items():
    shutil.copyfile(root / 'work/final-evidence' / original, target / name)

files = []
for directory in ['work/final-evidence','work/final-verified','work/final-closed','.playwright-cli']:
    for path in (root / directory).rglob('*'):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(part.startswith('tmp-') or part in {'wheel-install','final-wheel-installed'} for part in relative.parts):
            continue
        files.append(path)
files += list(root.glob('*.xml'))
files += [root/'work'/name for name in ['run_checks.py','pw.ps1','flow_host.py','observed_cli.py',
    'check_authorization.py','check_cold_integrity.py','summarize_evidence.py','protected_bytes.py','package_final_evidence.py']]
earlier = root.parent / 'm3p-final-integration/work/pytest-trust.xml'
manifest = []
archive = target / 'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as package:
    for path in sorted(set(files)):
        name = path.relative_to(root).as_posix()
        data = path.read_bytes()
        package.writestr(name,data)
        manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    if earlier.exists():
        data = earlier.read_bytes()
        name = 'early-sandbox-rehearsal/pytest-trust.xml'
        package.writestr(name,data)
        manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
record = dict(archive='evidence.zip',bytes=archive.stat().st_size,
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=manifest,
    scope='Only public synthetic test data, browser artifacts and test scripts; no Provider keys or personal profiles.')
(target/'MANIFEST.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in record.items() if k != 'files'},indent=2))
