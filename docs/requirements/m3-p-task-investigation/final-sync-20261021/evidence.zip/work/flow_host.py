"""Test-only synthetic Host; real UI/HTTP, existing scripted extraction adapter."""
import json
from pathlib import Path
from threading import Event
from tests.integration.test_product_application_flow import _start_product_server, _stop_product_server
from tests.integration.test_stale_decision_revalidation import explicit_claim

root = Path('work/final-evidence/browser-c')
root.mkdir(parents=True, exist_ok=True)
unknown = dict(explicit_claim('Cedar', '03'), relation='negotiates with')
base, server, worker, app = _start_product_server(root, [
    explicit_claim('Birchline', '01'), unknown, explicit_claim('Wrenwell', '07'),
])
(root / 'host.json').write_text(json.dumps({'url': base, 'provider': 'existing scripted FakeProvider',
    'production_http': True, 'synthetic': True}), encoding='utf-8')
print(base, flush=True)
try:
    Event().wait()
except KeyboardInterrupt:
    pass
finally:
    _stop_product_server(server, worker, app)
