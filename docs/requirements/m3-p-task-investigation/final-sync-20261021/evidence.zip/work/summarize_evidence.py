"""Summarize unmodified browser network receipts and JUnit outcomes."""
from datetime import datetime, timezone
import json
from pathlib import Path
import xml.etree.ElementTree as ET

out = Path('work/final-evidence')
trace = Path('.playwright-cli/traces/trace-1792583982801.network')
events = []
for line in trace.read_text(encoding='utf8').splitlines():
    row = json.loads(line).get('snapshot')
    if not row:
        continue
    request = row['request']
    response = row['response']
    entry = dict(started=row['startedDateTime'], method=request['method'], url=request['url'],
                 elapsed_ms=row['time'], http_status=response['status'])
    content_file = response.get('content', {}).get('_file')
    if content_file:
        try:
            payload = json.loads((trace.parent / content_file).read_text(encoding='utf8'))
            result = payload.get('result') or {}
            entry.update(result_status=result.get('status'), agent_run_id=result.get('agent_run_id'))
        except (ValueError, OSError, AttributeError):
            pass
    events.append(entry)
summary = dict(recorded_at=datetime.now(timezone.utc).isoformat(), events=events,
    count=len(events), max_request_ms=max(e['elapsed_ms'] for e in events),
    http_errors=[e for e in events if e['http_status'] >= 400])
(out / 'browser-network-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf8')
tests = []
for base in [Path('.'), out]:
    for path in base.glob('*.xml'):
        try:
            root = ET.parse(path).getroot()
        except ET.ParseError:
            continue
        suites = [root] if root.tag == 'testsuite' else root.findall('testsuite')
        tests.append(dict(path=str(path), suites=[dict(s.attrib) for s in suites]))
(out / 'junit-summary.json').write_text(json.dumps(tests, indent=2), encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k != 'events'}, indent=2))
