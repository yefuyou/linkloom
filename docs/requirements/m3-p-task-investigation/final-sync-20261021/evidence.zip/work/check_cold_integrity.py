"""Controlled tampering of copies of synthetic Runtime data, followed by HTTP cold read."""
from dataclasses import replace
import json
from pathlib import Path
import shutil
import sys
from linkloom.runtime.checkpoint import SQLiteCheckpointer
from tests.m3p_support import cold_read

source = Path('work/final-evidence/http-final')
out = Path(sys.argv[1] if len(sys.argv) > 1 else 'work/final-evidence/cold-integrity')
out.mkdir(exist_ok=False)
for mode in ['ledger_missing', 'reviewer_rejected']:
    copy = out / mode
    shutil.copytree(source, copy)
    base = copy / 'work/investigations'
    pointer = json.loads(next(base.glob('ui-*.json')).read_text(encoding='utf8'))
    root = base / pointer['root']
    cp = SQLiteCheckpointer(root / 'runtime')
    state = cp.get_latest(pointer['thread_id'])
    if mode == 'ledger_missing':
        cp.save(replace(state, tool_ledger=[], step_seq=state.step_seq + 1))
    else:
        path = root / 'runtime' / state.result_ref
        result = json.loads(path.read_text(encoding='utf8'))
        result['review']['decision'] = 'evidence_insufficient'
        path.write_text(json.dumps(result, ensure_ascii=False), encoding='utf8')
    code, payload = cold_read(copy / 'product.sqlite', pointer['run_id'], pointer['workspace_id'])
    (copy / 'cold-http.json').write_text(json.dumps([code, payload], ensure_ascii=False, indent=2), encoding='utf8')
    saved = payload['result']
    assert code == 200 and saved['status'] == 'BLOCKED', saved
    assert not saved['evidence'] and not saved.get('task_review') and not saved['trace'], saved
    print(mode, 'PASS', flush=True)
