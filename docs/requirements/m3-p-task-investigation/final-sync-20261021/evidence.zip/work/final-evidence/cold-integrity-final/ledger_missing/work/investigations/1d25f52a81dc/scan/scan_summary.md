# Scan Summary

- Notes indexed: 2
- Warnings: 0

## Notes

- `src_080d54850a1a46fd88a984379d59b7f2.md` - src_080d54850a1a46fd88a984379d59b7f2
- `src_a7b99b8301884ad5bb3c34300792729d.md` - src_a7b99b8301884ad5bb3c34300792729d

## Warnings

- None
