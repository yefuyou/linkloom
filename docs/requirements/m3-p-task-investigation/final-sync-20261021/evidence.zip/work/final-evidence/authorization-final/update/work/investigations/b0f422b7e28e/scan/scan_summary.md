# Scan Summary

- Notes indexed: 2
- Warnings: 0

## Notes

- `src_dabc10327d0b42a7910a30d5f8f1bf10.md` - src_dabc10327d0b42a7910a30d5f8f1bf10
- `src_e8f1e0c4b2b640beb7b460f980ce37c2.md` - src_e8f1e0c4b2b640beb7b460f980ce37c2

## Warnings

- None
