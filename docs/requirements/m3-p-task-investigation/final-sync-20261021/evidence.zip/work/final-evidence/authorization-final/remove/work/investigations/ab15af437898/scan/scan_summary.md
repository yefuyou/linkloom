# Scan Summary

- Notes indexed: 2
- Warnings: 0

## Notes

- `src_1cc4c318dfca4c23b189b49f1d0ee9a0.md` - src_1cc4c318dfca4c23b189b49f1d0ee9a0
- `src_2db322042bd04bca968b1a689e125d5b.md` - src_2db322042bd04bca968b1a689e125d5b

## Warnings

- None
