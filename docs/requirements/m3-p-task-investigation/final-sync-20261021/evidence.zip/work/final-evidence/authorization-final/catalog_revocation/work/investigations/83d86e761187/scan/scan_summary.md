# Scan Summary

- Notes indexed: 2
- Warnings: 0

## Notes

- `src_7e2341b9fbdd435a8e2e9c5cef2cfc0c.md` - src_7e2341b9fbdd435a8e2e9c5cef2cfc0c
- `src_c5615c22e7674565bc23da401d33a054.md` - src_c5615c22e7674565bc23da401d33a054

## Warnings

- None
