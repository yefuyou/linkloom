# Scan Summary

- Notes indexed: 2
- Warnings: 0

## Notes

- `src_79b1a1a8ce86451fa7ca6ae1b20d77d0.md` - src_79b1a1a8ce86451fa7ca6ae1b20d77d0
- `src_7db5212a48d94285af5946e66acf50af.md` - src_7db5212a48d94285af5946e66acf50af

## Warnings

- None
