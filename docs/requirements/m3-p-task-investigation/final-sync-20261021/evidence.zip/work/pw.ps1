$env:PLAYWRIGHT_BROWSERS_PATH = Join-Path $PSScriptRoot 'pw-browsers'
$env:PLAYWRIGHT_CLI_OUTPUT_DIR = Join-Path $PSScriptRoot 'final-evidence/browser-cli'
$nodePath = 'C:/Users/18019/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
$cliPath = Join-Path $PSScriptRoot 'npm-cache/_npx/31e32ef8478fbf80/node_modules/@playwright/cli/playwright-cli.js'
"`n$([DateTime]::UtcNow.ToString('o')) playwright-cli $args" | Out-File -Append -Encoding utf8 (Join-Path $PSScriptRoot 'final-evidence/browser-cli.log')
& $nodePath $cliPath '-s=m3p-final' @args 2>&1 | Tee-Object -Append -FilePath (Join-Path $PSScriptRoot 'final-evidence/browser-cli.log')
