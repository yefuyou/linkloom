"""Compare existing protected Git blobs without updating any historical artifact."""
import json
from pathlib import Path
import re
import subprocess

def tree(ref):
    lines = subprocess.check_output(['git','ls-tree','-r',ref], text=True, encoding='utf8').splitlines()
    return {line.split('\t',1)[1]: line.split()[2] for line in lines if '\t' in line}

before, after = tree('13adb03c61df8c882a32ce71004b006f7a94fd9b'), tree('HEAD')
protected = [name for name in before if re.search(r'gold|seal|frozen|rehearsal.*ledger',name,re.I)]
changed = [name for name in protected if before[name] != after.get(name)]
result = dict(base='13adb03c61df8c882a32ce71004b006f7a94fd9b', count=len(protected),
              changed=changed, blobs={name:before[name] for name in protected})
Path('work/final-evidence/protected-blobs.json').write_text(json.dumps(result,indent=2),encoding='utf8')
assert not changed, changed
print('PASS', len(protected), 'existing protected Git blobs unchanged')
