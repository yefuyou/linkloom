"""Evidence-only replay of existing synthetic Host interfaces; not normal UI."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
from time import monotonic

from tests.m3p_support import revision_product, product_http, http_ask
from tests.integration.test_product_application_flow import _client
from tests.unit.test_task_relation_query import retract

out = Path(sys.argv[1] if len(sys.argv) > 1 else 'work/final-evidence/authorization')
out.mkdir(parents=True, exist_ok=False)
receipts = []

def save(root, name, value):
    (root / (name + '.json')).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

for mode in ['update', 'remove', 'catalog_revocation', 'relation_retract']:
    root = out / mode
    root.mkdir()
    started = monotonic()
    app, service, stages, ws, identity, _, _ = revision_product(root)
    record = dict(case=mode, workspace_id=ws, started=datetime.now(timezone.utc).isoformat())
    try:
        with product_http(app, service) as base:
            result = http_ask(base, ws)
            save(root, 'before', result)
            assert result['status'] == 'PARTIAL'
            sources = app.snapshot_investigation_sources(ws)[1]
            source = sources[0]
            if mode in ['update', 'remove']:
                # Use existing public product HTTP operation on a synthetic source.
                mutation = _client(base, '/api/sources/' + source['source_id'],
                    method='PUT' if mode == 'update' else 'DELETE',
                    data=dict(name=source['name'], content=source['content'] + ' 来源版本已更正。')
                        if mode == 'update' else None)
                save(root, 'mutation-http', mutation)
            elif mode == 'catalog_revocation':
                record['injection'] = 'test-only Evidence Catalog SQL revocation; no ordinary UI'
                with app.repository._lock, app.repository._connection:
                    app.repository._connection.execute(
                        'DELETE FROM ll_source_evidence WHERE workspace_id=? AND evidence_ref=?',
                        (ws, result['evidence'][0]['evidence_ref']))
            else:
                record['injection'] = 'existing test-only finite P4 lifecycle helper; no ordinary UI'
                retract(root / 'relations.sqlite', ws, identity.assessment_id)
            path = f"/api/product/ask/runs/{result['agent_run_id']}?workspace_id={ws}"
            hot = _client(base, path)
            save(root, 'hot', hot)
            blocked = hot[1]['result']
            assert hot[0] == 200 and blocked['status'] == 'BLOCKED'
            assert not blocked['evidence'] and not blocked['trace'] and not blocked.get('task_review')
            cross = _client(base, path.replace(ws, 'foreign-workspace'))
            save(root, 'cross-workspace', cross)
            assert cross[0] != 200
    finally:
        app.close()
    cold = subprocess.run([sys.executable, '-m', 'tests.m3p_support', str(root / 'product.sqlite'),
        result['agent_run_id'], ws, str(root / 'relations.sqlite')],
        capture_output=True, text=True, encoding='utf-8', timeout=120)
    (root / 'cold.stdout').write_text(cold.stdout, encoding='utf-8')
    (root / 'cold.stderr').write_text(cold.stderr, encoding='utf-8')
    assert cold.returncode == 0
    status, payload = json.loads(cold.stdout)
    save(root, 'cold', payload)
    blocked = payload['result']
    assert status == 200 and blocked['status'] == 'BLOCKED'
    assert not blocked['evidence'] and not blocked['trace'] and not blocked.get('task_review')
    record.update(status='PASS', elapsed_seconds=monotonic() - started)
    receipts.append(record)
    save(out, 'summary', receipts)
    print(mode, 'PASS', flush=True)
