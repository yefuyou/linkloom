# Scan Summary

- Notes indexed: 2
- Warnings: 0

## Notes

- `src_b39b49ac9a8044cf8c37888398feeb3c.md` - src_b39b49ac9a8044cf8c37888398feeb3c
- `src_d2142b03e996466d968d566a0a7c8d36.md` - src_d2142b03e996466d968d566a0a7c8d36

## Warnings

- None
