We selected Acme as the supplier for the Atlas project.
