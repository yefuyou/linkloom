Mira Chen is not the accountable owner of Lantern Plan.
