Mira Chen is the accountable owner of Lantern Plan.
