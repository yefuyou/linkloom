# Scan Summary

- Notes indexed: 2
- Warnings: 0

## Notes

- `negative.md` - negative
- `positive.md` - positive

## Warnings

- None
