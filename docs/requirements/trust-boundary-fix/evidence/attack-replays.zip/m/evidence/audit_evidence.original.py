"""Reproducible offline adversarial audit. Never imports the shared checkout."""
from __future__ import annotations
import copy
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'baseline'
sys.path.insert(0, str(BASE / 'src'))
sys.dont_write_bytecode = True
os.environ['LINKLOOM_RETRIEVAL_MODE'] = 'bm25'
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
OUT = ROOT / 'evidence'
OUT.mkdir(exist_ok=True)
# Every run uses new synthetic paths; existing evidence is retained.
from uuid import uuid4
DATA = OUT / ('data_' + uuid4().hex[:10])
DATA.mkdir()
import linkloom
from linkloom.agents.runtime_evidence import RuntimeEvidenceCatalogAdapter
from linkloom.decision_memory.sources import SourceReferenceRegistry
from linkloom.ui.product import ProductApplication
from linkloom.context.assembler import ContextAssembler, ContextBudget
from linkloom.retrieval_v2.models import RetrievedEvidence

H = runpy.run_path(str(BASE / 'tests/unit/test_runtime_evidence_bridge.py'))
R = runpy.run_path(str(BASE / 'tests/integration/test_runtime_agent_memory_capture.py'))
WORKSPACE = H['WORKSPACE']
RUN_ID = H['RUN_ID']
results = []

def record(case_id, name, fn):
    selected = os.environ.get('AUDIT_CASES')
    if selected and case_id not in selected.split(','):
        return
    try:
        actual = fn()
        row = {'id': case_id, 'name': name, **actual}
    except BaseException as exc:
        row = {'id':case_id, 'name':name, 'verdict':'HARNESS_ERROR',
               'exception':repr(exc), 'traceback':traceback.format_exc()}
    results.append(row)
    print(json.dumps(row, ensure_ascii=False), flush=True)

def bridge(passage=None, document=None, registry=None, workspace=WORKSPACE):
    document = document or H['_document']()
    passage = passage or H['_passage'](document)
    registry = registry or SourceReferenceRegistry()
    adapted = RuntimeEvidenceCatalogAdapter().build(
        run_id=RUN_ID, workspace_id=workspace, passages=[passage],
        documents=[document], source_registry=registry)
    return adapted, registry, passage

def mismatch(field, value):
    passage = H['_passage']()
    passage[field] = value
    a, reg, p = bridge(passage)
    return {'verdict':'PASS' if a.catalog.get(str(p['evidence_id'])) is None else 'FAIL',
            'blocked':[b.reason_code for b in a.blocked],
            'registered':reg.has_evidence(WORKSPACE,str(p['evidence_id']))}

record('E01','Runtime bridge foreign workspace',lambda:mismatch('workspace_id','foreign-workspace'))
record('E02','Same quote with substituted source identity',lambda:mismatch('source_ref','different.md'))
record('E03','Same quote with substituted source hash',lambda:mismatch('content_sha256','0'*64))
record('E04','Forged evidence ID',lambda:mismatch('evidence_id','ev_v2_forged'))

def version_conflict():
    p=H['_passage'](); reg=SourceReferenceRegistry()
    reg.register_evidence(WORKSPACE,p['evidence_id'],content_hash=p['content_sha256'],source_version='old-version')
    a,_,_=bridge(p,registry=reg)
    return {'verdict':'PASS' if a.catalog.get(p['evidence_id']) is None else 'FAIL',
            'blocked':[b.reason_code for b in a.blocked]}
record('E05','Explicit immutable version mismatch',version_conflict)

def revoked_replay():
    a,reg,p=bridge()
    reg.unregister_evidence(WORKSPACE,p['evidence_id'])
    before=reg.has_evidence(WORKSPACE,p['evidence_id'])
    replay,_,_=bridge(p,registry=reg)
    return {'verdict':'FAIL' if reg.has_evidence(WORKSPACE,p['evidence_id']) else 'PASS',
            'registered_after_revoke':before,'registered_after_replay':reg.has_evidence(WORKSPACE,p['evidence_id']),
            'catalog_accepted':replay.catalog.get(p['evidence_id']) is not None,
            'blocked':[b.reason_code for b in replay.blocked],
            'boundary':'adapter API supplied current document remains readable; no revocation tombstone'}
record('E06','Revoked registration replay',revoked_replay)

def search_only_final():
    from linkloom.agents.model_adapter import FakeModelAdapter, ModelAction
    from linkloom.tools.contracts import ToolCall
    folder=DATA/'search_only'; folder.mkdir()
    def search(request):
        context=json.loads(request.user_input.rsplit('team_decision_request=',1)[1])['source_context']
        return ModelAction.tool(ToolCall(call_id='find',tool_id='search_notes',
            arguments={'query':'Acme supplier','source_context':context,'limit':5}))
    def final(request):
        passage=next(x for x in request.observation.value if 'Acme' in x['quote'])
        return ModelAction.final(R['_decision_json'](passage['evidence_id']))
    model=FakeModelAdapter([search,final])
    _,_,engine,request=R['_runtime_fixture'](folder,model)
    status=engine.start_multi_agent(request)
    result=R['_result'](folder,status.run_id)
    # Result artifact is the actual Runtime user-facing projection.
    (folder/'observed_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    # Checkpoint access differs by checkpointer type; result and request trace remain primary evidence.
    tools=[action.observation.tool_id for action in model.requests if action.observation is not None]
    engine._decision_memory_store.close()
    return {'verdict':'FAIL' if result.get('status')=='completed' else 'PASS',
            'runtime_status':status.status,'user_status':result.get('status'),
            'review':result.get('review'),'result':result.get('result'),
            'memory_candidate':result.get('memory_candidate'),
            'observed_tool_results':tools,'provider_requests':len(model.requests),
            'artifact':str(folder/'observed_result.json')}
record('E07','Search-only final without read_verified_note',search_only_final)

def product_lifecycle():
    app=ProductApplication(database_path=DATA/'product.sqlite',extractor=None)
    w1=app.handle_post('/api/workspaces',{'name':'Audit A'})[0]['workspace']['workspace_id']
    p=app.handle_post('/api/sources/import',{'name':'a.md','content':'[2026-10-01T09:00:00Z] Alice: Alpha owns Task A.'})[0]['source']
    sid=p['source_id']; ref=app.repository.current_evidence(w1)[0]['evidence_ref']
    w2=app.handle_post('/api/workspaces',{'name':'Audit B'})[0]['workspace']['workspace_id']
    foreign=app.repository.get_source(w2,sid,include_content=True)
    foreign_evidence=app.repository.evidence_source(w2,ref)
    foreign_api=None
    try: app.handle_get('/api/sources/'+sid)
    except Exception as e: foreign_api=getattr(e,'code',str(e))
    results.append({'id':'E08','name':'Cross-workspace source and evidence read',
        'verdict':'PASS' if foreign is None and foreign_evidence is None and foreign_api=='SOURCE_NOT_FOUND' else 'FAIL',
        'source':foreign,'evidence':foreign_evidence,'api_error':foreign_api})
    app.handle_post('/api/workspaces/current',{'workspace_id':w1})
    before=app._evidence_payload(w1,ref)
    app.handle_delete('/api/sources/'+sid)
    deleted=app._evidence_payload(w1,ref)
    registry_after=app.store.source_registry.has_evidence(w1,ref)
    inventory_after=ref in app.repository.source_inventory()[w1]
    app.close()
    app=ProductApplication(database_path=DATA/'product.sqlite',extractor=None)
    cold=app._evidence_payload(w1,ref)
    cold_registry=app.store.source_registry.has_evidence(w1,ref)
    app.close()
    return {'verdict':'FAIL' if deleted.get('verified') or cold.get('verified') else 'PASS',
            'before':before,'deleted_evidence_payload':deleted,'cold_evidence_payload':cold,
            'registry_after_delete':registry_after,'inventory_after_delete':inventory_after,
            'cold_registry':cold_registry,
            'boundary':'evidence renderer independently marks historical span verified; current authority is separately revoked'}
record('E09','Deleted source UI evidence and cold restart',product_lifecycle)

def historical_same_quote():
    app=ProductApplication(database_path=DATA/'versions.sqlite',extractor=None)
    ws=app.handle_post('/api/workspaces',{'name':'Version audit'})[0]['workspace']['workspace_id']
    content='[2026-10-01T09:00:00Z] Alice: Alpha owns Task A.'
    src=app.handle_post('/api/sources/import',{'name':'meeting.md','content':content})[0]['source']
    sid=src['source_id']; old=app.repository.current_evidence(ws)[0]['evidence_ref']
    old_ver=src['source_version']
    app.handle_put('/api/sources/'+sid,{'name':'meeting.md','content':content+'\n[2026-10-02T09:00:00Z] Bob: Task A was cancelled.'})
    current_refs=[v['evidence_ref'] for v in app.repository.current_evidence(ws)]
    inventory=app.repository.source_inventory()[ws]
    payload=app._evidence_payload(ws,old)
    app.close()
    return {'verdict':'OBSERVED', 'old_version':old_ver,'old_ref':old,
            'old_ref_is_current_span':old in current_refs,'old_ref_in_current_inventory':old in inventory,
            'rendered':payload,'note':'Intentional continuity by exact timestamp/speaker/quote, same stable source; does not authorize another source'}
record('E10','Identical quote retained across a changed source version',historical_same_quote)

def compress_counterevidence():
    def ev(ref,text,rank):
        return RetrievedEvidence(evidence_id=ref,source_ref=ref+'.md',logical_path='/'+ref+'.md',score=1/rank,rank=rank,
            retrieval_channel='current',resource_id=ref+'.md',metadata={'text':text,'workspace_id':WORKSPACE,'status':'verified'})
    bundle=ContextAssembler(budget=ContextBudget(max_evidence=1)).assemble(workspace_id=WORKSPACE,query='Task A owner',
        retrieved_evidence=[ev('supports','Alice owns Task A.',1),ev('contradicts','Alice no longer owns Task A.',2)])
    return {'verdict':'OBSERVED','selected':[{'id':s.item_id,'content':s.text} for s in bundle.selected],
            'dropped':[{'id':d.item_id,'reason':str(d.reason)} for d in bundle.dropped],
            'text':bundle.rendered_text,'boundary':'No claim that this low-level compression alone bypasses final evidence gate'}
record('E11','Compression removes explicit counterevidence',compress_counterevidence)

def fabricated_answer_after_read():
    from linkloom.agents.model_adapter import FakeModelAdapter, ModelAction
    from linkloom.tools.contracts import ToolCall
    folder=DATA/'read_then_fabricate'; folder.mkdir()
    def search(request):
        context=json.loads(request.user_input.rsplit('team_decision_request=',1)[1])['source_context']
        return ModelAction.tool(ToolCall(call_id='find',tool_id='search_notes',
            arguments={'query':'Acme supplier','source_context':context,'limit':5}))
    def read(request):
        ev=next(x for x in request.observation.value if 'Acme' in x['quote'])
        return ModelAction.tool(ToolCall(call_id='read',tool_id='read_verified_note',arguments={'note_ref':ev['evidence_id']}))
    def final(request):
        value=json.loads(R['_decision_json'](request.observation.value['evidence_id']))
        value['decision']['value']='Contoso'
        value['rationale'][0]['point']='The source confirms Contoso won unanimously.'
        return ModelAction.final(json.dumps(value))
    model=FakeModelAdapter([search,read,final])
    _,_,engine,request=R['_runtime_fixture'](folder,model)
    status=engine.start_multi_agent(request)
    result=R['_result'](folder,status.run_id)
    (folder/'observed_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    engine._decision_memory_store.close()
    return {'verdict':'FAIL' if result.get('status')=='completed' else 'PASS',
        'runtime_status':status.status,'review':result.get('review'),'result':result.get('result'),
        'memory_candidate':result.get('memory_candidate'),'provider_requests':len(model.requests),
        'artifact':str(folder/'observed_result.json')}
record('E12','Real source read followed by fabricated supplier and rationale',fabricated_answer_after_read)

def cold_changed_source():
    from linkloom.runtime.checkpoint import SQLiteCheckpointer
    from linkloom.runtime.graph import RuntimeEngine
    from linkloom.agents.model_adapter import FakeModelAdapter,ModelAction
    from linkloom.scanner import scan_vault
    folder=DATA/'cold_changed_source'; folder.mkdir()
    cp=R['CrashAfterDurableFinal'](folder/'checkpoints')
    def search(req):
        from linkloom.tools.contracts import ToolCall
        context=json.loads(req.user_input.rsplit('team_decision_request=',1)[1])['source_context']
        return ModelAction.tool(ToolCall(call_id='find',tool_id='search_notes',
            arguments={'query':'Acme supplier','source_context':context,'limit':5}))
    def final(req):
        ev=next(x for x in req.observation.value if 'Acme' in x['quote'])
        return ModelAction.final(R['_decision_json'](ev['evidence_id']))
    vault,_,engine,request=R['_runtime_fixture'](folder,FakeModelAdapter([search,final]),checkpointer=cp)
    try:
        engine.start_multi_agent(request)
        raise AssertionError('crash point not reached')
    except R['SimulatedProcessCrash']:
        pass
    engine._decision_memory_store.close()
    (vault/'supplier.md').write_text('The supplier for Atlas is Contoso.\n',encoding='utf-8')
    model=FakeModelAdapter([ModelAction.final('should not need a model')])
    restarted=RuntimeEngine(vault_root=vault,index_path=scan_vault(vault,folder/'scan_changed').index_path,
        checkpoint_dir=folder/'checkpoints',trace_dir=folder/'traces_changed',model=model)
    try:
        status=restarted.resume_multi_agent(request.thread_id)
        result=R['_result'](folder,status.run_id)
        return {'verdict':'FAIL' if result.get('status')=='completed' else 'PASS','status':status.status,
            'result':result,'provider_requests':model.call_count}
    except Exception as e:
        return {'verdict':'PASS','termination':'exception','exception_type':type(e).__name__,
            'message':str(e),'provider_requests':model.call_count}
    finally:
        store=getattr(restarted,'_decision_memory_store',None)
        if store is not None: store.close()
record('E13','Cold checkpoint with changed current source',cold_changed_source)

def cherry_pick_after_reading_counterevidence():
    from linkloom.runtime.graph import RuntimeEngine
    from linkloom.runtime.models import RunRequest
    from linkloom.agents.model_adapter import FakeModelAdapter,ModelAction
    from linkloom.tools.contracts import ToolCall
    from linkloom.scanner import scan_vault
    folder=DATA/'known_conflict'; folder.mkdir(); vault=folder/'vault'; vault.mkdir()
    (vault/'positive.md').write_text('Mira Chen is the accountable owner of Lantern Plan.\n',encoding='utf-8')
    (vault/'negative.md').write_text('Mira Chen is not the accountable owner of Lantern Plan.\n',encoding='utf-8')
    refs={}
    def search(req):
        context=json.loads(req.user_input.rsplit('team_decision_request=',1)[1])['source_context']
        return ModelAction.tool(ToolCall(call_id='find',tool_id='search_notes',
            arguments={'query':'Lantern Plan owner','source_context':context,'limit':5}))
    def read_positive(req):
        for ev in req.observation.value:
            refs['negative' if 'is not' in ev['quote'] else 'positive']=ev['evidence_id']
        assert set(refs)=={'positive','negative'},refs
        return ModelAction.tool(ToolCall(call_id='positive',tool_id='read_verified_note',arguments={'note_ref':refs['positive']}))
    def read_negative(req):
        return ModelAction.tool(ToolCall(call_id='negative',tool_id='read_verified_note',arguments={'note_ref':refs['negative']}))
    def final(req):
        value=json.loads(R['_decision_json'](refs['positive']))
        value['decision']['value']='Mira Chen is the accountable owner of Lantern Plan.'
        value['rationale']=[]
        return ModelAction.final(json.dumps(value))
    model=FakeModelAdapter([search,read_positive,read_negative,final])
    engine=RuntimeEngine(vault_root=vault,index_path=scan_vault(vault,folder/'scan').index_path,
        checkpoint_dir=folder/'checkpoints',trace_dir=folder/'traces',model=model)
    request=RunRequest(request_id='known-conflict',thread_id='known-conflict-thread',workflow='team_decision',
        query='Who is the accountable owner of Lantern Plan?',max_steps=7,max_provider_requests=7,dry_run=True)
    status=engine.start_multi_agent(request)
    result=R['_result'](folder,status.run_id)
    reads=[x for x in result.get('tool_ledger',[]) if x['tool_id']=='read_verified_note' and x['status']=='completed']
    from linkloom.agents.claim_grounding import assess_claim_text
    both={r['result']['value']['evidence_id']:r['result']['value'] for r in reads}
    expected=assess_claim_text('Mira Chen is the accountable owner of Lantern Plan.',list(both),both)
    (folder/'observed_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    engine._decision_memory_store.close()
    return {'verdict':'FAIL' if result.get('status')=='completed' else 'PASS','status':status.status,
        'read_count':len(reads),'assessment_with_both_read_sources':expected.status.value,
        'review':result.get('review'),'result':result.get('result'),
        'provider_requests':model.call_count,'artifact':str(folder/'observed_result.json')}
record('E15','Final omits known read counterevidence and claims no uncertainty',cherry_pick_after_reading_counterevidence)

def repeated_search():
    from dataclasses import replace
    from linkloom.agents.model_adapter import FakeModelAdapter,ModelAction
    from linkloom.tools.contracts import ToolCall
    folder=DATA/'repeated_search'; folder.mkdir()
    def search(req):
        context=json.loads(req.user_input.rsplit('team_decision_request=',1)[1])['source_context']
        return ModelAction.tool(ToolCall(call_id='again',tool_id='search_notes',
            arguments={'query':'Acme supplier','source_context':context,'limit':5}))
    model=FakeModelAdapter([search]*12)
    _,_,engine,req=R['_runtime_fixture'](folder,model)
    req=replace(req,max_steps=8,max_provider_requests=8)
    status=engine.start_multi_agent(req); result=R['_result'](folder,status.run_id)
    (folder/'observed_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    engine._decision_memory_store.close()
    return {'verdict':'PASS' if result.get('status')!='completed' and model.call_count<=8 else 'FAIL',
        'status':status.status,'error':result.get('error'),'result':result.get('result'),
        'model_calls':model.call_count,'tool_calls':len(result.get('tool_ledger',[])),
        'artifact':str(folder/'observed_result.json')}
record('E16','Repeated identical searches terminate without trusted final',repeated_search)

def partial_with_unsupported_fact():
    from linkloom.agents.model_adapter import FakeModelAdapter,ModelAction
    from linkloom.agents.team_decision import TeamDecisionResult
    from linkloom.tools.contracts import ToolCall
    folder=DATA/'partial_unsupported'; folder.mkdir()
    schema_checked=[]
    def search(req):
        context=json.loads(req.user_input.rsplit('team_decision_request=',1)[1])['source_context']
        return ModelAction.tool(ToolCall(call_id='find',tool_id='search_notes',
            arguments={'query':'Acme supplier','source_context':context,'limit':5}))
    def read(req):
        ev=next(x for x in req.observation.value if 'Acme' in x['quote'])
        return ModelAction.tool(ToolCall(call_id='read',tool_id='read_verified_note',arguments={'note_ref':ev['evidence_id']}))
    def final(req):
        ref=req.observation.value['evidence_id']
        payload=json.loads(R['_decision_json'](ref))
        payload['decision']['status']='partial'
        payload['rationale'].append({'point':'Contoso is the accountable owner of Atlas.','evidence_refs':[ref]})
        payload['uncertainty']={'status':'partial','statement':None,'unknown_fields':['project_owner'],'evidence_refs':[]}
        TeamDecisionResult.from_dict(payload)
        schema_checked.append(True)
        return ModelAction.final(json.dumps(payload))
    model=FakeModelAdapter([search,read,final])
    _,_,engine,req=R['_runtime_fixture'](folder,model)
    status=engine.start_multi_agent(req); result=R['_result'](folder,status.run_id)
    (folder/'observed_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    engine._decision_memory_store.close()
    return {'verdict':'PASS' if schema_checked and result.get('status')=='failed' else 'FAIL',
        'schema_was_valid':bool(schema_checked),'status':status.status,'error':result.get('error'),
        'result':result.get('result'),'model_calls':model.call_count,'artifact':str(folder/'observed_result.json')}
record('E17','Schema-valid PARTIAL mixes supported and unsupported facts',partial_with_unsupported_fact)

def task_deadline():
    from dataclasses import replace
    import time
    from linkloom.agents.model_adapter import FakeModelAdapter,ModelAction
    from linkloom.agents.retrieval_agent import RetrievalAgent
    from linkloom.runtime.artifacts import ModelArtifactStore
    from linkloom.tools.registry import ToolRegistry
    from linkloom.tools.runtime import ToolRuntime
    from linkloom.tools.contracts import ToolCall
    hp=runpy.run_path(str(BASE/'tests/unit/test_product_evidence_context_scope.py'))
    value=hp['_evidence']('ev_deadline',hp['PRODUCT_WORKSPACE'])
    source={'workspace_id':hp['PRODUCT_WORKSPACE'],'vault_root_fingerprint':hp['VAULT_FINGERPRINT']}
    def slow(_args):
        time.sleep(0.1)
        return [value]
    registry=ToolRegistry(); registry.register(hp['_search_definition'](),slow)
    model=FakeModelAdapter([
        ModelAction.tool(ToolCall(call_id='slow',tool_id='search_notes',arguments={'query':'product evidence','source_context':source,'limit':5})),
        ModelAction.final(hp['_approved_final']('ev_deadline'))])
    agent=RetrievalAgent(model=model,initial_state=hp['_state'](),artifact_store=ModelArtifactStore(DATA/'deadline/models'),
        state_checkpoint_callback=lambda _state:None,expected_workspace_id=hp['PRODUCT_WORKSPACE'])
    task=replace(hp['_task'](),deadline_ms=1)
    start=time.perf_counter()
    result=agent.execute(task,query='product evidence',source_context=source,policy_enforcer=hp['_policy'](),tool_runtime=ToolRuntime(registry))
    elapsed=(time.perf_counter()-start)*1000
    return {'verdict':'OBSERVED','declared_deadline_ms':1,'executor_sleep_ms':100,'elapsed_ms':elapsed,
        'status':result.status,'error':result.error,'model_calls':model.call_count,
        'output_type':result.output_type,'summary':result.summary,
        'note':'The synchronous executor ran past task deadline; no infinite hang was attempted'}
record('E18','AgentTask deadline does not preempt synchronous executor',task_deadline)

payload={'baseline_sha':'ca2e775ce17581f8b69b2e1f9daf813a1230fb1c',
         'module_path':str(linkloom.__file__),'data_dir':str(DATA),'results':results}
result_file=OUT/os.environ.get('AUDIT_RESULT_FILE','results.json')
result_file.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
print('RESULT_FILE='+str(result_file),flush=True)
