# Scan Summary

- Notes indexed: 2
- Warnings: 0

## Notes

- `src_5e3980d96add482193e0c404135cf8cd.md` - src_5e3980d96add482193e0c404135cf8cd
- `src_98163a52629646f19f4eac1b7f6c51f4.md` - src_98163a52629646f19f4eac1b7f6c51f4

## Warnings

- None
