# Scan Summary

- Notes indexed: 2
- Warnings: 0

## Notes

- `src_255e6ebdedfd49af8a4e2c7c594532f1.md` - src_255e6ebdedfd49af8a4e2c7c594532f1
- `src_43a10f0b6c7144c8ae97e0f4e960b80b.md` - src_43a10f0b6c7144c8ae97e0f4e960b80b

## Warnings

- None
