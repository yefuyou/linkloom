# Scan Summary

- Notes indexed: 2
- Warnings: 0

## Notes

- `src_2d88e78d071f43b8a41da0dfcc59b1c3.md` - src_2d88e78d071f43b8a41da0dfcc59b1c3
- `src_959a1d4fac6d463397e0f83af779118d.md` - src_959a1d4fac6d463397e0f83af779118d

## Warnings

- None
